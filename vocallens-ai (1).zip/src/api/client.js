/**
 * VocalLens AI - Frontend API Client
 * Wraps backend routes with structured error handling and safe JSON parsing.
 */

const API_BASE = '';

async function safeFetch(url, options = {}) {
  const res = await fetch(url, options);
  const contentType = res.headers.get('content-type') || '';

  // If response is not JSON (e.g., HTML fallback from SPA router)
  if (!contentType.includes('application/json')) {
    const rawText = await res.text();
    console.warn(`[VocalLens API] Non-JSON response from ${url} (${res.status}):`, rawText.slice(0, 150));
    throw new Error(`API error (${res.status}): Expected JSON response from server.`);
  }

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data?.detail || `Request failed with status ${res.status}`);
  }
  return data;
}

export async function checkHealth() {
  return safeFetch(`${API_BASE}/api/health`);
}

export async function fetchBaseline() {
  return safeFetch(`${API_BASE}/api/baseline`);
}

export async function analyzeAudio(audioBlobOrFile, language = 'en', clientTranscript = '', clientWords = [], durationSec = 0) {
  const formData = new FormData();
  
  // Determine proper filename extension from mime type or object
  let defaultExt = 'wav';
  if (audioBlobOrFile?.type?.includes('webm')) defaultExt = 'webm';
  else if (audioBlobOrFile?.type?.includes('ogg')) defaultExt = 'ogg';
  else if (audioBlobOrFile?.type?.includes('mp3') || audioBlobOrFile?.type?.includes('mpeg')) defaultExt = 'mp3';
  
  const originalName = audioBlobOrFile.name || `recorded_speech_${Date.now()}.${defaultExt}`;
  formData.append('file', audioBlobOrFile, originalName);
  formData.append('language', language);
  formData.append('user_id', 'default_user');
  if (clientTranscript) {
    formData.append('client_transcript', clientTranscript);
  }
  if (Array.isArray(clientWords) && clientWords.length > 0) {
    formData.append('client_words', JSON.stringify(clientWords));
  }
  if (durationSec > 0) {
    formData.append('duration', String(durationSec));
  }

  return safeFetch(`${API_BASE}/api/analyze`, {
    method: 'POST',
    body: formData,
  });
}

export async function fetchSessions() {
  return safeFetch(`${API_BASE}/api/sessions`);
}

export async function fetchSessionDetail(sessionId) {
  if (!sessionId) throw new Error('Session ID is required');
  return safeFetch(`${API_BASE}/api/sessions/${sessionId}`);
}

export async function fetchProgress() {
  return safeFetch(`${API_BASE}/api/progress`);
}

export async function fetchDemoSession(type = 'flagship') {
  return safeFetch(`${API_BASE}/api/demo-session?type=${type}`);
}

export async function deleteSession(sessionId) {
  if (!sessionId) throw new Error('Session ID is required');
  return safeFetch(`${API_BASE}/api/sessions/${sessionId}`, {
    method: 'DELETE',
  });
}

export async function transcribeAudio(audioBlobOrFile, language = 'en') {
  const formData = new FormData();
  let defaultExt = 'wav';
  if (audioBlobOrFile?.type?.includes('webm')) defaultExt = 'webm';
  else if (audioBlobOrFile?.type?.includes('ogg')) defaultExt = 'ogg';
  else if (audioBlobOrFile?.type?.includes('mp3') || audioBlobOrFile?.type?.includes('mpeg')) defaultExt = 'mp3';

  formData.append('file', audioBlobOrFile, audioBlobOrFile.name || `transcribe_input_${Date.now()}.${defaultExt}`);
  formData.append('language', language);

  const res = await safeFetch(`${API_BASE}/api/transcribe`, {
    method: 'POST',
    body: formData,
  });

  if (res.success === false) {
    throw new Error(res.error || 'Audio transcription failed.');
  }

  return res;
}

export async function sendChatMessage(messages, modelType = 'general', useSearch = false) {
  return safeFetch(`${API_BASE}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, modelType, useSearch }),
  });
}

export async function fetchSearchGrounding(query) {
  return safeFetch(`${API_BASE}/api/search-grounding`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
  });
}

export async function generateCorrectedAudio(transcriptText, flawEvents = [], sessionId = '') {
  return safeFetch(`${API_BASE}/api/generate-corrected-audio`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      transcript_text: transcriptText,
      flaw_events: flawEvents,
      session_id: sessionId,
    }),
  });
}

export async function sendLiveVoiceMessage(userSpeech, history = []) {
  return safeFetch(`${API_BASE}/api/live-voice`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      user_speech: userSpeech,
      history,
    }),
  });
}
