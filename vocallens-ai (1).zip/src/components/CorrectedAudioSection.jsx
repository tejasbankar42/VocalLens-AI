import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  Copy,
  Check,
  Volume2,
  VolumeX,
  FileAudio,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Zap,
} from 'lucide-react';
import { generateCorrectedAudio } from '../api/client';

export default function CorrectedAudioSection({ report }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState(
    report?.corrected_audio_path || '/audio/demo_flagship.wav'
  );
  const [correctedText, setCorrectedText] = useState(
    report?.corrected_transcript_text ||
      'Good morning everyone. Today I am pleased to present the key milestones of our project. Over the past quarter, our engineering team has developed a scalable, high-performance architecture that delivers consistent results.'
  );
  const [improvements, setImprovements] = useState(
    report?.improvements || [
      {
        category: 'Filler Elimination',
        description: 'Removed all verbal fillers ("um", "uh", "like", "basically") to project cognitive confidence and poise.',
      },
      {
        category: 'Fluency & Restarts',
        description: 'Resolved stuttered restarts ("we we built") into decisive, authoritative action verbs.',
      },
      {
        category: 'Pacing & Cadence',
        description: 'Calibrated delivery tempo to an optimal 140 WPM with steady 0.5s punctuation breaths.',
      },
      {
        category: 'Diction & Inflection',
        description: 'Enhanced consonant termination with downward declarative sentence inflection.',
      },
    ]
  );

  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [activeTab, setActiveTab] = useState('corrected'); // 'corrected' | 'original'

  const audioRef = useRef(null);

  // Sync state if report changes
  useEffect(() => {
    if (report) {
      if (report.corrected_audio_path) {
        setAudioUrl(report.corrected_audio_path);
      }
      if (report.corrected_transcript_text) {
        setCorrectedText(report.corrected_transcript_text);
      }
      if (report.improvements) {
        setImprovements(report.improvements);
      }
    }
  }, [report]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch((e) => console.warn('Audio play notice:', e));
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      if (audioRef.current.duration && !isNaN(audioRef.current.duration)) {
        setDuration(audioRef.current.duration);
      }
    }
  };

  const handleSeek = (e) => {
    const target = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = target;
      setCurrentTime(target);
    }
  };

  const handleRestart = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(correctedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRegenerate = async () => {
    setIsGenerating(true);
    try {
      const res = await generateCorrectedAudio(
        report.transcript_text || correctedText,
        report.flaw_events || [],
        report.session_id || 'session_' + Date.now()
      );
      if (res.corrected_audio_path) {
        setAudioUrl(res.corrected_audio_path);
      }
      if (res.corrected_transcript_text) {
        setCorrectedText(res.corrected_transcript_text);
      }
      if (res.improvements) {
        setImprovements(res.improvements);
      }
    } catch (err) {
      console.warn('Error regenerating corrected audio:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const formatTime = (secs) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="p-6 rounded-2xl glass-panel border border-emerald-500/20 bg-gradient-to-b from-slate-900/90 via-slate-950/80 to-slate-900/90 space-y-6">
      {/* Hidden HTML5 Audio Element */}
      <audio
        ref={audioRef}
        src={activeTab === 'corrected' ? audioUrl : report?.audio_path || '/audio/demo_flawed.wav'}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
        onEnded={() => setIsPlaying(false)}
      />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
        <div>
          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <span className="font-semibold text-emerald-400 uppercase tracking-wider">
              Exemplar Audio & Script
            </span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-400 font-mono">gemini-3.8-flash-lite-tts</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-300 font-semibold">100% Flaws Corrected</span>
          </div>
          <h2 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-white mt-1 flex items-center space-x-2">
            <span>Model Speech Delivery & Corrected Script</span>
            <Sparkles className="w-5 h-5 text-emerald-400" />
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Listen to how your speech sounds when delivered with optimal 140 WPM pacing, zero filler words, and executive articulation.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleRegenerate}
            disabled={isGenerating}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-300 border border-emerald-500/30 text-xs font-semibold shadow-sm transition-all disabled:opacity-50"
            title="Regenerate corrected audio with Gemini TTS"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? 'Synthesizing...' : 'Regenerate Audio'}</span>
          </button>
        </div>
      </div>

      {/* Audio Comparison Player Bar */}
      <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/80 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Track Selector Tabs */}
        <div className="flex items-center space-x-1 bg-slate-900 border border-slate-800 p-1 rounded-lg text-xs w-full md:w-auto">
          <button
            onClick={() => {
              if (audioRef.current) audioRef.current.pause();
              setIsPlaying(false);
              setActiveTab('corrected');
            }}
            className={`flex-1 md:flex-none px-3 py-1.5 rounded-md font-semibold transition-all flex items-center justify-center space-x-1.5 ${
              activeTab === 'corrected'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>AI Corrected Delivery</span>
          </button>
          <button
            onClick={() => {
              if (audioRef.current) audioRef.current.pause();
              setIsPlaying(false);
              setActiveTab('original');
            }}
            className={`flex-1 md:flex-none px-3 py-1.5 rounded-md font-semibold transition-all flex items-center justify-center space-x-1.5 ${
              activeTab === 'original'
                ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileAudio className="w-3.5 h-3.5 text-brand-400" />
            <span>Original Recording</span>
          </button>
        </div>

        {/* Playback Controls & Scrubber */}
        <div className="flex items-center space-x-3 w-full md:w-2/3">
          <button
            onClick={togglePlay}
            className="w-10 h-10 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center font-bold shadow-lg shadow-emerald-500/20 transition-all flex-shrink-0"
            title={isPlaying ? 'Pause' : 'Play Audio'}
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
          </button>

          <button
            onClick={handleRestart}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 transition-colors flex-shrink-0"
            title="Restart from beginning"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          {/* Time Scrubber */}
          <div className="flex-1 flex items-center space-x-2">
            <span className="text-[11px] font-mono text-slate-400 tabular-nums w-8 text-right">
              {formatTime(currentTime)}
            </span>
            <input
              type="range"
              min="0"
              max={duration || 10}
              step="0.1"
              value={currentTime}
              onChange={handleSeek}
              className="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <span className="text-[11px] font-mono text-slate-400 tabular-nums w-8">
              {formatTime(duration || 10)}
            </span>
          </div>
        </div>
      </div>

      {/* Side-by-Side Transcript Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Original Transcript */}
        <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-slate-800/60">
            <span className="font-semibold text-slate-400">
              Original Spoken Transcript
            </span>
            <span className="text-[11px] text-rose-400 font-mono">
              Contains identified flaws
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed font-mono whitespace-pre-wrap bg-slate-900/60 p-3 rounded-lg min-h-[90px]">
            {report?.transcript_text || 'No spoken transcript available.'}
          </p>
        </div>

        {/* Corrected Model Script */}
        <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-emerald-500/20">
            <span className="font-semibold text-emerald-300 flex items-center space-x-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Corrected Model Script (Exemplar Prose)</span>
            </span>
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1 text-[11px] text-emerald-400 hover:text-emerald-200 transition-colors"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />}
              <span>{copied ? 'Copied' : 'Copy Script'}</span>
            </button>
          </div>
          <p className="text-xs text-emerald-100 leading-relaxed font-mono whitespace-pre-wrap bg-slate-950/70 p-3 rounded-lg min-h-[90px] border border-emerald-500/20">
            {correctedText}
          </p>
        </div>
      </div>

      {/* Point-by-Point Corrections Applied */}
      <div className="space-y-2.5 pt-2">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Key Corrections & Enhancements Applied
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {improvements.map((imp, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1"
            >
              <div className="flex items-center space-x-1.5 text-xs font-bold text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                <span>{imp.category}</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                {imp.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
