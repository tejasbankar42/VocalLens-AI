import React from 'react';
import { Award, Sparkles, TrendingUp, AlertTriangle } from 'lucide-react';

export default function ScoreGauge({ score = 0, band = 'Good' }) {
  const safeScore = Math.max(0, Math.min(100, Number(score) || 0));

  // Determine color scheme based on band or score
  const getTheme = () => {
    if (safeScore >= 85 || band === 'Excellent') {
      return {
        stroke: '#10b981', // emerald-500
        gradientFrom: '#10b981',
        gradientTo: '#14b8a6',
        text: 'text-emerald-400',
        bg: 'bg-emerald-500/10',
        border: 'border-emerald-500/30',
        label: 'Excellent Delivery',
        sub: 'Executive-level clarity, optimal pacing, and crisp enunciation.',
      };
    }
    if (safeScore >= 70 || band === 'Good') {
      return {
        stroke: '#14b8a6', // teal-500
        gradientFrom: '#14b8a6',
        gradientTo: '#06b6d4',
        text: 'text-brand-300',
        bg: 'bg-brand-500/10',
        border: 'border-brand-500/30',
        label: 'Good Delivery',
        sub: 'Solid conversational flow with minor opportunities in pacing.',
      };
    }
    if (safeScore >= 50 || band === 'Needs work') {
      return {
        stroke: '#f59e0b', // amber-500
        gradientFrom: '#f59e0b',
        gradientTo: '#ea580c',
        text: 'text-amber-400',
        bg: 'bg-amber-500/10',
        border: 'border-amber-500/30',
        label: 'Needs Work',
        sub: 'Noticeable filler density or dead pauses affecting engagement.',
      };
    }
    return {
      stroke: '#f43f5e', // rose-500
      gradientFrom: '#f43f5e',
      gradientTo: '#e11d48',
      text: 'text-rose-400',
      bg: 'bg-rose-500/10',
      border: 'border-rose-500/30',
      label: 'Significant Improvements Needed',
      sub: 'Frequent disfluencies, pauses >1.5s, or rushed pacing detected.',
    };
  };

  const theme = getTheme();

  // SVG circular arc calculations
  const radius = 68;
  const strokeWidth = 10;
  const circumference = 2 * Math.PI * radius;
  // Use a 260 degree arc for gauge look
  const strokeDashoffset = circumference - (safeScore / 100) * circumference;

  return (
    <div className="p-6 rounded-2xl glass-panel h-full flex flex-col justify-between items-center text-center relative overflow-hidden">
      {/* Background radial glow */}
      <div
        className="absolute w-40 h-40 rounded-full blur-3xl opacity-15 pointer-events-none"
        style={{ background: theme.gradientFrom }}
      />

      {/* Card Header */}
      <div className="w-full flex items-center justify-between pb-2 border-b border-slate-800/80">
        <span className="text-xs font-semibold tracking-wider uppercase text-slate-400">
          Overall Delivery Score
        </span>
        <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md border ${theme.bg} ${theme.border} ${theme.text}`}>
          {band || theme.label}
        </span>
      </div>

      {/* Circular Gauge */}
      <div className="relative my-4 flex items-center justify-center">
        <svg className="w-44 h-44 transform -rotate-90" viewBox="0 0 160 160">
          {/* Background circle */}
          <circle
            cx="80"
            cy="80"
            r={radius}
            stroke="#1e293b"
            strokeWidth={strokeWidth}
            fill="transparent"
          />
          {/* Progress circle */}
          <circle
            cx="80"
            cy="80"
            r={radius}
            stroke={theme.stroke}
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>

        {/* Center Text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display font-extrabold text-4xl text-white tracking-tight tabular-nums">
            {safeScore.toFixed(1)}
          </span>
          <span className="text-[11px] text-slate-400 font-mono mt-0.5">out of 100</span>
        </div>
      </div>

      {/* Summary Description */}
      <div className="pt-2 border-t border-slate-800/60 w-full text-left">
        <p className="text-xs text-slate-300 leading-snug">
          {theme.sub}
        </p>
      </div>
    </div>
  );
}
