import React from 'react';
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip,
} from 'recharts';

export default function RadarChartComponent({ dimensionScores = {} }) {
  const dimensions = [
    { key: 'clarity', label: 'Clarity' },
    { key: 'fluency', label: 'Fluency' },
    { key: 'pace', label: 'Pacing' },
    { key: 'pauses', label: 'Pauses' },
    { key: 'fillers', label: 'Fillers' },
    { key: 'pronunciation', label: 'Diction' },
    { key: 'confidence', label: 'Confidence' },
    { key: 'vocabulary', label: 'Lexicon' },
  ];

  const data = dimensions.map((d) => {
    const rawVal = dimensionScores?.[d.key];
    const val = typeof rawVal === 'number' ? rawVal : 75;
    return {
      subject: d.label,
      score: Math.round(val * 10) / 10,
      fullMark: 100,
    };
  });

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const p = payload[0];
      return (
        <div className="bg-slate-900 border border-slate-700/80 p-2.5 rounded-xl shadow-xl text-xs space-y-1">
          <p className="font-bold text-white">{p.payload.subject}</p>
          <p className="text-brand-300 font-mono font-semibold">
            Score: <span className="tabular-nums">{p.value}</span> / 100
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-6 rounded-2xl glass-panel h-full flex flex-col justify-between">
      <div className="flex items-center justify-between pb-2 border-b border-slate-800/80 mb-2">
        <h3 className="text-xs font-semibold tracking-wider uppercase text-slate-400">
          8-Dimension Diagnostic Radar
        </h3>
        <span className="text-[11px] font-mono text-brand-400">
          Contrastive Rubric
        </span>
      </div>

      <div className="w-full h-64 flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart cx="50%" cy="50%" outerRadius="75%" data={data}>
            <PolarGrid stroke="#334155" strokeDasharray="3 3" />
            <PolarAngleAxis
              dataKey="subject"
              tick={{ fill: '#94a3b8', fontSize: 11, fontWeight: 500 }}
            />
            <PolarRadiusAxis
              angle={30}
              domain={[0, 100]}
              tick={{ fill: '#64748b', fontSize: 9 }}
              stroke="#334155"
            />
            <Radar
              name="User Speech"
              dataKey="score"
              stroke="#14b8a6"
              fill="#14b8a6"
              fillOpacity={0.35}
            />
            <Tooltip content={<CustomTooltip />} />
          </RadarChart>
        </ResponsiveContainer>
      </div>

      <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
        <span>Target: &gt; 80 on all dimensions</span>
        <span className="text-emerald-400 font-semibold">Calibrated Model</span>
      </div>
    </div>
  );
}
