import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Mic,
  Square,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  AlertCircle,
  CheckCircle2,
  Clock,
  Radio,
} from 'lucide-react';

/**
 * AudioRecorder Component
 *
 * Uses the Web MediaRecorder API and Web Audio API (AudioContext + AnalyserNode)
 * to capture audio from the user's microphone for downstream speech analysis.
 *
 * Props:
 * - onAudioReady: callback function called with { blob, url, duration, mimeType }
 * - onReset: optional callback when recording is cleared
 * - maxDurationSeconds: optional maximum recording time in seconds (default: 300 / 5 mins)
 * - visualizerColor: optional hex or gradient for visualizer
 */
export default function AudioRecorder({
  onAudioReady,
  onReset,
  maxDurationSeconds = 300,
}) {
  // Recorder states: 'idle' | 'recording' | 'paused' | 'stopped'
  const [recorderState, setRecorderState] = useState('idle');
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [recordedBlob, setRecordedBlob] = useState(null);
  const [recordedUrl, setRecordedUrl] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [audioLevel, setAudioLevel] = useState(0); // 0 to 100 for volume meter
  const [supportedMimeType, setSupportedMimeType] = useState('');

  // Audio preview playback states
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [previewTime, setPreviewTime] = useState(0);
  const [previewDuration, setPreviewDuration] = useState(0);

  // Refs for Web Audio API & MediaRecorder
  const mediaRecorderRef = useRef(null);
  const audioStreamRef = useRef(null);
  const audioChunksRef = useRef([]);
  const timerIntervalRef = useRef(null);
  const canvasRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const animationFrameRef = useRef(null);
  const previewAudioRef = useRef(null);
  const elapsedSecondsRef = useRef(0);
  const recognitionRef = useRef(null);
  const liveTranscriptRef = useRef('');
  const liveWordsRef = useRef([]);

  // Detect supported audio mimeType on mount
  useEffect(() => {
    if (typeof MediaRecorder !== 'undefined') {
      const types = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/ogg;codecs=opus',
        'audio/ogg',
        'audio/wav',
        'audio/mp4',
      ];
      for (const t of types) {
        if (MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t)) {
          setSupportedMimeType(t);
          break;
        }
      }
    }
  }, []);

  // Cleanup all audio resources on unmount
  const cleanupAudioResources = useCallback(() => {
    // Stop recording timer
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }

    // Stop speech recognition
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
      recognitionRef.current = null;
    }

    // Cancel visualizer animation frame
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    // Stop all media tracks
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((track) => track.stop());
      audioStreamRef.current = null;
    }

    // Close AudioContext
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }

    // Reset analyzer ref
    analyserRef.current = null;
  }, []);

  useEffect(() => {
    return () => {
      cleanupAudioResources();
      if (recordedUrl) {
        URL.revokeObjectURL(recordedUrl);
      }
    };
  }, [cleanupAudioResources, recordedUrl]);

  // Start Real-Time Canvas Audio Frequency Visualizer
  const startCanvasVisualizer = (stream) => {
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;

      const audioCtx = new AudioContextClass();
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64;
      analyser.smoothingTimeConstant = 0.8;
      source.connect(analyser);
      analyserRef.current = analyser;

      const canvas = canvasRef.current;
      if (!canvas) return;
      const canvasCtx = canvas.getContext('2d');
      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const renderFrame = () => {
        animationFrameRef.current = requestAnimationFrame(renderFrame);
        analyser.getByteFrequencyData(dataArray);

        // Compute volume level
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const avg = sum / bufferLength;
        setAudioLevel(Math.min(100, Math.round((avg / 255) * 120)));

        canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
        const barWidth = (canvas.width / bufferLength) * 1.5;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const barHeight = (dataArray[i] / 255) * canvas.height * 0.9;

          // Gradient color: teal -> cyan
          const gradient = canvasCtx.createLinearGradient(0, canvas.height, 0, 0);
          gradient.addColorStop(0, '#0d9488'); // teal-600
          gradient.addColorStop(0.5, '#14b8a6'); // teal-500
          gradient.addColorStop(1, '#2dd4bf'); // teal-400

          canvasCtx.fillStyle = gradient;
          canvasCtx.fillRect(
            x,
            (canvas.height - barHeight) / 2,
            barWidth - 1.5,
            barHeight
          );
          x += barWidth;
        }
      };

      renderFrame();
    } catch (e) {
      console.warn('AudioContext visualizer initialization notice:', e);
    }
  };

  // Start Microphone Recording
  const startRecording = async () => {
    setErrorMessage('');
    setRecordedBlob(null);
    if (recordedUrl) {
      URL.revokeObjectURL(recordedUrl);
      setRecordedUrl(null);
    }
    setElapsedSeconds(0);
    elapsedSecondsRef.current = 0;
    liveTranscriptRef.current = '';
    liveWordsRef.current = [];
    audioChunksRef.current = [];

    // Verify browser support
    if (!navigator?.mediaDevices?.getUserMedia) {
      setErrorMessage(
        'Microphone input is not supported by your browser or environment.'
      );
      return;
    }

    try {
      // Start live speech recognition if browser supports it
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        try {
          const recognizer = new SpeechRecognition();
          recognizer.continuous = true;
          recognizer.interimResults = true;
          recognizer.lang = 'en-US';

          let startTimestamp = Date.now();

          recognizer.onresult = (event) => {
            let fullText = '';
            const wordsList = [];

            for (let i = 0; i < event.results.length; i++) {
              const res = event.results[i];
              const chunkText = res[0]?.transcript || '';
              fullText += (fullText ? ' ' : '') + chunkText;
            }

            liveTranscriptRef.current = fullText.trim();

            const tokens = fullText.trim().split(/\s+/).filter(Boolean);
            const totalDuration = Math.max(1, elapsedSecondsRef.current || (Date.now() - startTimestamp) / 1000);
            const timeStep = totalDuration / Math.max(tokens.length, 1);

            tokens.forEach((tok, idx) => {
              wordsList.push({
                word: tok,
                start: Math.round(idx * timeStep * 100) / 100,
                end: Math.round((idx * timeStep + Math.min(timeStep * 0.8, 0.5)) * 100) / 100,
                probability: 0.95,
              });
            });

            liveWordsRef.current = wordsList;
          };

          recognizer.onerror = (e) => {
            console.warn('[Speech Recognition] notice:', e.error);
          };

          recognizer.start();
          recognitionRef.current = recognizer;
        } catch (recErr) {
          console.warn('[Speech Recognition] initialization notice:', recErr);
        }
      }

      // Request high quality mono 16kHz speech stream
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      audioStreamRef.current = stream;
      startCanvasVisualizer(stream);

      const mimeType = supportedMimeType || 'audio/webm';
      const options = mimeType ? { mimeType } : undefined;
      const mediaRecorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = mediaRecorder;

      // Handle recorded data chunks
      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      // Handle recording stop event
      mediaRecorder.onstop = () => {
        const actualMime = mediaRecorder.mimeType || mimeType || 'audio/webm';
        const blob = new Blob(audioChunksRef.current, { type: actualMime });
        const url = URL.createObjectURL(blob);
        const finalDuration = Math.max(1, elapsedSecondsRef.current);

        setRecordedBlob(blob);
        setRecordedUrl(url);
        setRecorderState('stopped');

        // Stop speech recognition
        if (recognitionRef.current) {
          try {
            recognitionRef.current.stop();
          } catch (e) {}
          recognitionRef.current = null;
        }

        // Cleanup stream & visualizer
        if (audioStreamRef.current) {
          audioStreamRef.current.getTracks().forEach((track) => track.stop());
          audioStreamRef.current = null;
        }
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
          animationFrameRef.current = null;
        }
        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
          audioContextRef.current.close().catch(() => {});
          audioContextRef.current = null;
        }
        setAudioLevel(0);

        // Notify parent callback
        if (onAudioReady) {
          onAudioReady({
            blob,
            url,
            duration: finalDuration,
            mimeType: actualMime,
            transcript: liveTranscriptRef.current,
            words: liveWordsRef.current,
          });
        }
      };

      // Collect audio chunks every 250ms
      mediaRecorder.start(250);
      setRecorderState('recording');

      // Start elapsed timer
      timerIntervalRef.current = setInterval(() => {
        setElapsedSeconds((prev) => {
          const next = prev + 1;
          elapsedSecondsRef.current = next;
          if (next >= maxDurationSeconds) {
            stopRecording();
            return maxDurationSeconds;
          }
          return next;
        });
      }, 1000);
    } catch (err) {
      console.warn('Microphone access notice:', err);
      let msg = 'Could not access microphone.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        msg = 'Microphone permission was denied. Please allow microphone access in your browser.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        msg = 'No microphone device was detected on your system.';
      } else if (err.name === 'NotReadableError') {
        msg = 'Microphone is currently in use by another application.';
      } else {
        msg = err.message || 'Microphone initialization failed.';
      }
      setErrorMessage(msg);
      setRecorderState('idle');
      cleanupAudioResources();
    }
  };

  // Stop Recording
  const stopRecording = () => {
    if (mediaRecorderRef.current && (recorderState === 'recording' || recorderState === 'paused')) {
      mediaRecorderRef.current.stop();
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
  };

  // Pause Recording
  const pauseRecording = () => {
    if (mediaRecorderRef.current && recorderState === 'recording') {
      mediaRecorderRef.current.pause();
      setRecorderState('paused');
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
      if (audioContextRef.current && audioContextRef.current.state === 'running') {
        audioContextRef.current.suspend().catch(() => {});
      }
    }
  };

  // Resume Recording
  const resumeRecording = () => {
    if (mediaRecorderRef.current && recorderState === 'paused') {
      mediaRecorderRef.current.resume();
      setRecorderState('recording');

      timerIntervalRef.current = setInterval(() => {
        setElapsedSeconds((prev) => {
          if (prev + 1 >= maxDurationSeconds) {
            stopRecording();
            return maxDurationSeconds;
          }
          return prev + 1;
        });
      }, 1000);

      if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume().catch(() => {});
      }
    }
  };

  // Reset / Clear Recording
  const handleReset = () => {
    cleanupAudioResources();
    if (recordedUrl) {
      URL.revokeObjectURL(recordedUrl);
    }
    setRecordedBlob(null);
    setRecordedUrl(null);
    setElapsedSeconds(0);
    setRecorderState('idle');
    setErrorMessage('');
    setIsPlayingPreview(false);
    if (onReset) onReset();
  };

  // Format seconds to mm:ss
  const formatTime = (totalSec) => {
    const mins = Math.floor(totalSec / 60);
    const secs = Math.floor(totalSec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Toggle in-app preview audio playback
  const togglePreviewPlay = () => {
    if (!previewAudioRef.current) return;
    if (isPlayingPreview) {
      previewAudioRef.current.pause();
      setIsPlayingPreview(false);
    } else {
      previewAudioRef.current
        .play()
        .then(() => setIsPlayingPreview(true))
        .catch((e) => console.warn('Audio preview notice:', e));
    }
  };

  return (
    <div className="w-full rounded-2xl glass-panel p-6 border border-slate-800/80 bg-gradient-to-b from-slate-900/90 via-slate-950/80 to-slate-900/90 space-y-5">
      {/* Hidden audio element for preview playback */}
      {recordedUrl && (
        <audio
          ref={previewAudioRef}
          src={recordedUrl}
          onTimeUpdate={() => {
            if (previewAudioRef.current) {
              setPreviewTime(previewAudioRef.current.currentTime);
            }
          }}
          onLoadedMetadata={() => {
            if (previewAudioRef.current) {
              setPreviewDuration(previewAudioRef.current.duration);
            }
          }}
          onEnded={() => {
            setIsPlayingPreview(false);
            setPreviewTime(0);
          }}
        />
      )}

      {/* Header & Status Indicator */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div
            className={`w-3 h-3 rounded-full transition-colors ${
              recorderState === 'recording'
                ? 'bg-rose-500 animate-ping'
                : recorderState === 'paused'
                ? 'bg-amber-400'
                : recorderState === 'stopped'
                ? 'bg-emerald-400'
                : 'bg-slate-600'
            }`}
          />
          <span className="text-xs font-semibold tracking-wider uppercase text-slate-300">
            {recorderState === 'recording' && 'Live Audio Recording'}
            {recorderState === 'paused' && 'Recording Paused'}
            {recorderState === 'stopped' && 'Speech Captured'}
            {recorderState === 'idle' && 'Microphone Ready'}
          </span>
        </div>

        {/* Timer Display */}
        <div className="flex items-center space-x-2 px-3 py-1 rounded-lg bg-slate-950/80 border border-slate-800">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span className="font-mono text-sm font-bold text-brand-300 tabular-nums">
            {formatTime(elapsedSeconds)}
          </span>
          <span className="text-[11px] text-slate-500">/ {formatTime(maxDurationSeconds)}</span>
        </div>
      </div>

      {/* Live Waveform Canvas & Decibel Level Meter */}
      <div className="relative rounded-xl bg-slate-950/90 border border-slate-800/90 p-4 overflow-hidden">
        <canvas
          ref={canvasRef}
          width={600}
          height={80}
          className="w-full h-20 block"
        />

        {/* Overlay when idle or stopped */}
        {recorderState === 'idle' && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-950/60 backdrop-blur-[2px] text-xs text-slate-400">
            <Mic className="w-4 h-4 mr-2 text-slate-500" />
            <span>Click &quot;Start Recording&quot; to capture speech</span>
          </div>
        )}

        {recorderState === 'stopped' && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80 backdrop-blur-[2px] text-xs text-emerald-300">
            <CheckCircle2 className="w-4 h-4 mr-2 text-emerald-400" />
            <span>Audio stream recorded ({formatTime(elapsedSeconds)})</span>
          </div>
        )}

        {/* Live Decibel / Level Bar during recording */}
        {recorderState === 'recording' && (
          <div className="absolute bottom-2 left-4 right-4 flex items-center space-x-2">
            <Radio className="w-3 h-3 text-rose-400 animate-pulse" />
            <div className="flex-1 bg-slate-800/80 h-1 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-teal-400 to-rose-400 transition-all duration-75"
                style={{ width: `${audioLevel}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-slate-400 w-8 text-right">
              {audioLevel}%
            </span>
          </div>
        )}
      </div>

      {/* Error Message Box */}
      {errorMessage && (
        <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Control Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
        {/* State 1: Idle - Start Button */}
        {recorderState === 'idle' && (
          <button
            onClick={startRecording}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-brand-500 via-teal-400 to-cyan-500 text-slate-950 font-bold text-xs tracking-wide shadow-lg shadow-brand-500/20 hover:brightness-110 transition-all flex items-center justify-center space-x-2"
          >
            <Mic className="w-4 h-4 fill-current" />
            <span>START RECORDING</span>
          </button>
        )}

        {/* State 2: Recording or Paused - Controls */}
        {(recorderState === 'recording' || recorderState === 'paused') && (
          <div className="flex items-center space-x-2 w-full sm:w-auto">
            {/* Pause / Resume Button */}
            {recorderState === 'recording' ? (
              <button
                onClick={pauseRecording}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors flex items-center space-x-1.5"
              >
                <Pause className="w-3.5 h-3.5" />
                <span>Pause</span>
              </button>
            ) : (
              <button
                onClick={resumeRecording}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors flex items-center space-x-1.5"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Resume</span>
              </button>
            )}

            {/* Stop Recording Button */}
            <button
              onClick={stopRecording}
              className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs tracking-wider shadow-lg shadow-rose-600/30 transition-all flex items-center space-x-2"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>STOP RECORDING</span>
            </button>
          </div>
        )}

        {/* State 3: Stopped - Preview Playback Bar & Reset */}
        {recorderState === 'stopped' && (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 w-full">
            {/* Audio Preview Controls */}
            <div className="flex items-center space-x-2.5 w-full sm:w-auto">
              <button
                onClick={togglePreviewPlay}
                className="w-9 h-9 rounded-full bg-brand-500 hover:bg-brand-400 text-slate-950 flex items-center justify-center font-bold shadow-md shadow-brand-500/20 transition-all flex-shrink-0"
                title={isPlayingPreview ? 'Pause preview' : 'Play preview'}
              >
                {isPlayingPreview ? (
                  <Pause className="w-4 h-4 fill-current" />
                ) : (
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                )}
              </button>

              <div className="text-xs font-mono text-slate-300">
                <span className="text-brand-300 tabular-nums">
                  {formatTime(previewTime)}
                </span>
                <span className="text-slate-500"> / </span>
                <span className="tabular-nums">
                  {formatTime(previewDuration || elapsedSeconds)}
                </span>
              </div>
            </div>

            {/* Re-record / Discard Button */}
            <button
              onClick={handleReset}
              className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 text-xs font-medium transition-colors flex items-center space-x-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Re-record Speech</span>
            </button>
          </div>
        )}

        {/* Audio Specs Pill */}
        {supportedMimeType && (
          <div className="text-[11px] text-slate-500 font-mono hidden md:block">
            Codec: {supportedMimeType.replace(';codecs=', ' ')}
          </div>
        )}
      </div>
    </div>
  );
}
