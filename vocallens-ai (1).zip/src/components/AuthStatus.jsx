import React, { useState, useEffect } from 'react';
import { LogIn, LogOut, User, CheckCircle2, Cloud, Sparkles } from 'lucide-react';
import { auth, googleProvider, signInWithPopup, signOut, onAuthStateChanged, db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';

export default function AuthStatus({ user, setUser }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          // Persist user profile to Firestore
          const userRef = doc(db, 'users', currentUser.uid);
          await setDoc(userRef, {
            userId: currentUser.uid,
            email: currentUser.email || '',
            displayName: currentUser.displayName || 'Anonymous User',
            photoURL: currentUser.photoURL || '',
            lastLogin: new Date().toISOString(),
          }, { merge: true });
        } catch (e) {
          console.warn('Firestore profile sync notice:', e);
        }
      }
    });

    return () => unsubscribe();
  }, [setUser]);

  const handleSignIn = async () => {
    setError('');
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error('Firebase Auth Sign-In error:', err);
      setError(err.message || 'Google sign-in failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Sign-out error:', err);
    }
  };

  if (user) {
    return (
      <div className="flex items-center space-x-2">
        <div className="flex items-center space-x-2 px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200">
          {user.photoURL ? (
            <img src={user.photoURL} alt={user.displayName} className="w-5 h-5 rounded-full ring-1 ring-brand-400" />
          ) : (
            <div className="w-5 h-5 rounded-full bg-brand-500/20 text-brand-300 flex items-center justify-center font-bold text-[10px]">
              {user.displayName ? user.displayName[0] : 'U'}
            </div>
          )}
          <span className="hidden sm:inline font-medium max-w-[100px] truncate">
            {user.displayName || user.email?.split('@')[0]}
          </span>
          <span className="inline-flex items-center text-[10px] text-emerald-400 font-mono" title="Firestore Connected">
            <Cloud className="w-3 h-3 text-emerald-400 mr-0.5" />
            <span className="hidden md:inline">Synced</span>
          </span>
        </div>

        <button
          onClick={handleSignOut}
          className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 transition-colors"
          title="Sign out"
        >
          <LogOut className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className="flex items-center space-x-2">
      {error && (
        <span className="text-[10px] text-rose-400 hidden lg:inline max-w-[120px] truncate" title={error}>
          {error}
        </span>
      )}
      <button
        onClick={handleSignIn}
        disabled={loading}
        className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-brand-500/15 hover:bg-brand-500/25 text-brand-300 border border-brand-500/30 shadow-sm transition-all duration-150 disabled:opacity-50"
      >
        <LogIn className="w-3.5 h-3.5 text-brand-400" />
        <span>{loading ? 'Signing in...' : 'Sign In with Google'}</span>
      </button>
    </div>
  );
}
