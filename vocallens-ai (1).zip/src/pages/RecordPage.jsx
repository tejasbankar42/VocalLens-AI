import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Upload,
  Globe,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Clock,
  AudioWaveform,
  Play,
  FileAudio,
  BarChart2,
  GitCompare,
  TrendingUp,
  Database,
  MessageSquare,
  Search,
  ArrowRight,
  ShieldCheck,
  Zap,
  Copy,
  Check,
} from 'lucide-react';
import { analyzeAudio, transcribeAudio } from '../api/client';
import { db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { saveLocalSession } from '../lib/localStorageService';
import AudioRecorder from '../components/AudioRecorder';

export default function RecordPage({ onAnalysisComplete, onSelectDemo, onNavigateTab = () => {}, user }) {
  // State
  const [inputMode, setInputMode] = useState('mic'); // 'mic' | 'upload'
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [language, setLanguage] = useState('en');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisStep, setAnalysisStep] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [transcribedText, setTranscribedText] = useState('');
  const [userSpokenTranscript, setUserSpokenTranscript] = useState('');
  const [liveWords, setLiveWords] = useState([]);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [copied, setCopied] = useState(false);

  // Refs for recording & Web Audio API
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const timerIntervalRef = useRef(null);
  const canvasRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const animationFrameRef = useRef(null);
  const fileInputRef = useRef(null);

  // Clean up timer and audio context on unmount
  useEffect(() => {
    return () => {
      clearInterval(timerIntervalRef.current);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (audioContextRef.current) audioContextRef.current.close().catch(() => {});
    };
  }, []);

  // Live Waveform Visualizer
  const startCanvasVisualizer = (stream) => {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    audioContextRef.current = ctx;

    const source = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 64;
    source.connect(analyser);
    analyserRef.current = analyser;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const canvasCtx = canvas.getContext('2d');
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      animationFrameRef.current = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);

      canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
      const barWidth = (canvas.width / bufferLength) * 1.5;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * canvas.height * 0.9;
        
        // Gradient color from teal to cyan
        const grad = canvasCtx.createLinearGradient(0, canvas.height, 0, 0);
        grad.addColorStop(0, '#0d9488');
        grad.addColorStop(1, '#2dd4bf');

        canvasCtx.fillStyle = grad;
        canvasCtx.fillRect(x, (canvas.height - barHeight) / 2, barWidth - 1, barHeight);
        x += barWidth;
      }
    };
    draw();
  };

  // Start Mic Recording
  const startRecording = async () => {
    setErrorMessage('');
    setAudioBlob(null);
    setAudioUrl(null);
    setSelectedFile(null);
    setRecordingSeconds(0);

    try {
      if (!navigator?.mediaDevices?.getUserMedia) {
        throw new Error('Microphone access is not supported in this browser context. Please use "Upload Audio File" or "Demo Mode" instead.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      startCanvasVisualizer(stream);

      const mimeType = (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported('audio/webm'))
        ? 'audio/webm'
        : (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported('audio/ogg'))
        ? 'audio/ogg'
        : 'audio/wav';

      const mediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: mimeType || 'audio/wav' });
        setAudioBlob(blob);
        setAudioUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach((track) => track.stop());
        if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
        if (audioContextRef.current) audioContextRef.current.close().catch(() => {});
      };

      mediaRecorder.start(250); // collect chunks every 250ms
      setIsRecording(true);

      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.warn('Microphone error handled:', err);
      let msg = 'Could not access microphone.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        msg = 'Microphone permission was denied. Please allow microphone access or upload an audio file below.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        msg = 'No microphone device detected. You can upload an audio file below.';
      } else {
        msg = err.message || 'Microphone initialization failed. Please upload an audio file below.';
      }
      setErrorMessage(msg);
      setIsRecording(false);
    }
  };

  // Stop Mic Recording
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(timerIntervalRef.current);
    }
  };

  // Handle File Upload
  const handleFileChange = (e) => {
    setErrorMessage('');
    const file = e.target.files[0];
    if (!file) return;

    // Check size (< 50MB)
    if (file.size > 50 * 1024 * 1024) {
      setErrorMessage('Audio file size exceeds the 50MB limit.');
      return;
    }

    setSelectedFile(file);
    setAudioBlob(file);
    setAudioUrl(URL.createObjectURL(file));
  };

  // Run Analysis Pipeline with Progress Animation
  const handleAnalyze = async () => {
    const fileToAnalyze = selectedFile || audioBlob;
    if (!fileToAnalyze) {
      setErrorMessage('Please record your voice or select an audio file first.');
      return;
    }

    if (recordingSeconds > 0 && recordingSeconds < 5) {
      setErrorMessage('Audio is too short (must be at least 5.0 seconds of speech for accurate contrastive evaluation).');
      return;
    }

    setErrorMessage('');
    setIsAnalyzing(true);

    const steps = [
      'Uploading audio to secure processing pipeline...',
      'Running faster-whisper ASR & word timestamp alignment...',
      'Extracting acoustic prosody, pitch dynamics & RMS energy...',
      'Contrasting speech dimensions against ideal & flawed benchmarks...',
      'Grounding temporal flaw markers & synthesizing actionable feedback...',
    ];

    let stepIdx = 0;
    setAnalysisStep(steps[0]);
    const stepInterval = setInterval(() => {
      stepIdx++;
      if (stepIdx < steps.length) {
        setAnalysisStep(steps[stepIdx]);
      }
    }, 1800);

    try {
      const activeTranscript = userSpokenTranscript || transcribedText || '';
      const report = await analyzeAudio(fileToAnalyze, language, activeTranscript, liveWords, recordingSeconds);
      clearInterval(stepInterval);
      setIsAnalyzing(false);

      // Persist session to local storage
      saveLocalSession(report);

      // Persist session to Firestore if user is authenticated
      if (user) {
        try {
          await setDoc(doc(db, 'users', user.uid, 'sessions', report.session_id), {
            sessionId: report.session_id,
            userId: user.uid,
            filename: report.filename,
            overallScore: report.overall_score,
            band: report.band,
            wpm: report.wpm,
            pauseCount: report.pause_count,
            fillerCount: report.filler_count,
            duration: report.duration,
            transcriptText: report.transcript_text,
            createdAt: report.created_at || new Date().toISOString(),
          });
        } catch (fsErr) {
          console.warn('Firestore session persistence notice:', fsErr);
        }
      }

      onAnalysisComplete(report);
    } catch (err) {
      clearInterval(stepInterval);
      setIsAnalyzing(false);
      setErrorMessage(err.message || 'Analysis failed. Please try again.');
    }
  };

  // Instant Audio Transcription using Groq Whisper STT
  const handleTranscribe = async () => {
    const fileToTranscribe = selectedFile || audioBlob;
    if (!fileToTranscribe) {
      setErrorMessage('Please record your voice or select an audio file first.');
      return;
    }

    setErrorMessage('');
    setIsTranscribing(true);
    setTranscribedText('');

    try {
      const result = await transcribeAudio(fileToTranscribe, language);
      const text = result.text || 'No intelligible speech detected.';
      setTranscribedText(text);
      setUserSpokenTranscript(text);
    } catch (err) {
      setErrorMessage(err.message || 'Transcription failed.');
    } finally {
      setIsTranscribing(false);
    }
  };

  const handleCopy = () => {
    if (transcribedText) {
      navigator.clipboard.writeText(transcribedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const formatTime = (secs) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      {/* Hero Header */}
      <div className="text-center space-y-3 pt-2">
        <div className="text-xs uppercase font-semibold tracking-wider text-brand-400">
          Contrastive Speech Analytics <span aria-hidden="true">·</span> Temporal Flaw Grounding
        </div>
        <h1 className="font-display text-3xl sm:text-5xl font-extrabold tracking-tight text-white text-balance">
          Speak with poise. <br className="hidden sm:inline" />
          <span className="bg-gradient-to-r from-brand-300 via-teal-200 to-cyan-300 bg-clip-text text-transparent">
            Calibrate every dimension.
          </span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto leading-relaxed text-balance">
          Record or upload audio to evaluate your delivery against verified contrastive benchmarks, pinpointing exact temporal flaws across your speech timeline.
        </p>
      </div>

      {/* Quick Judge Showcase Banner */}
      <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/5 backdrop-blur flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 text-amber-300">
          <Sparkles className="w-4 h-4 flex-shrink-0" />
          <span>
            <strong>Judging or demoing?</strong> Load a pre-analyzed session immediately without recording:
          </span>
        </div>
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <button
            onClick={() => onSelectDemo('flagship')}
            className="flex-1 sm:flex-none px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 font-medium transition-colors"
          >
            Ideal Session (89.5)
          </button>
          <button
            onClick={() => onSelectDemo('flawed')}
            className="flex-1 sm:flex-none px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 font-medium transition-colors"
          >
            Flawed Session (51.8)
          </button>
        </div>
      </div>

      {/* Error Alert */}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start space-x-2 animate-in fade-in">
          <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Recording / Upload Card */}
      <div className="p-6 sm:p-8 rounded-2xl glass-panel space-y-6">
        {/* Language & Settings Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <Globe className="w-4 h-4 text-brand-400" />
            <label htmlFor="languageSelect" className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              Speech Language
            </label>
          </div>
          <select
            id="languageSelect"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            disabled={isRecording || isAnalyzing}
            className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-400"
          >
            <option value="en">English (Global / Standard)</option>
            <option value="hinglish">Hinglish / Indian English (with matlab/toh support)</option>
            <option value="hi">Hindi (Devanagari)</option>
          </select>
        </div>

        {/* Mode Selector: Live Microphone vs Upload */}
        <div className="flex items-center space-x-1 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs">
          <button
            onClick={() => setInputMode('mic')}
            className={`flex-1 py-2 px-3 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-all ${
              inputMode === 'mic'
                ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Mic className="w-3.5 h-3.5 text-brand-400" />
            <span>Live Microphone (Web MediaRecorder API)</span>
          </button>
          <button
            onClick={() => setInputMode('upload')}
            className={`flex-1 py-2 px-3 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-all ${
              inputMode === 'upload'
                ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            <span>Upload Audio File</span>
          </button>
        </div>

        {/* Input Mode: Microphone Component */}
        {inputMode === 'mic' ? (
          <AudioRecorder
            onAudioReady={({ blob, url, duration, transcript, words }) => {
              setAudioBlob(blob);
              setAudioUrl(url);
              setRecordingSeconds(duration);
              setSelectedFile(null);
              if (transcript) {
                setUserSpokenTranscript(transcript);
                setTranscribedText(transcript);
              }
              if (words) {
                setLiveWords(words);
              }
            }}
            onReset={() => {
              setAudioBlob(null);
              setAudioUrl(null);
              setRecordingSeconds(0);
              setSelectedFile(null);
              setUserSpokenTranscript('');
              setTranscribedText('');
              setLiveWords([]);
            }}
          />
        ) : (
          /* File Upload Dropzone */
          <div
            onClick={() => fileInputRef.current && fileInputRef.current.click()}
            className="p-8 rounded-xl bg-slate-900/60 border border-slate-800 border-dashed hover:border-brand-500/50 cursor-pointer flex flex-col items-center justify-center space-y-3 transition-colors text-center"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="w-14 h-14 rounded-full bg-slate-800 hover:bg-slate-700 text-brand-400 flex items-center justify-center transition-colors">
              <Upload className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                {selectedFile ? selectedFile.name : 'Choose Audio File or Drag & Drop'}
              </span>
              <p className="text-[11px] text-slate-500 mt-1">
                WAV, MP3, M4A, WEBM, or OGG up to 50MB
              </p>
            </div>
            {audioUrl && (
              <audio src={audioUrl} controls className="h-8 max-w-xs mt-2" />
            )}
          </div>
        )}

        {/* Spoken Transcript Verification & Editor */}
        {(audioBlob || selectedFile) && (
          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-700/80 space-y-2.5 animate-in fade-in">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <span className="font-semibold text-teal-300 flex items-center space-x-1.5">
                  <CheckCircle2 className="w-4 h-4 text-teal-400" />
                  <span>Speech Transcript & Precision Calibration</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-teal-500/10 text-teal-300 border border-teal-500/20 font-mono">
                  {userSpokenTranscript ? `${userSpokenTranscript.split(/\s+/).filter(Boolean).length} words` : 'Audio Ready'}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                {userSpokenTranscript && (
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(userSpokenTranscript);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                    className="flex items-center space-x-1 text-[11px] text-slate-400 hover:text-slate-200"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                )}
              </div>
            </div>
            <textarea
              rows={2}
              value={userSpokenTranscript}
              onChange={(e) => {
                setUserSpokenTranscript(e.target.value);
                setTranscribedText(e.target.value);
              }}
              placeholder="Spoken words will appear here live during recording, or click 'Transcribe with AI' below to auto-transcribe your uploaded file..."
              className="w-full bg-slate-950/70 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-400 font-mono leading-relaxed"
            />
            <p className="text-[11px] text-slate-400 flex items-center justify-between">
              <span>Your actual spoken words are used to precisely calibrate speech pacing, filler words, and pronunciation metrics.</span>
            </p>
          </div>
        )}

        {/* Actions: Transcribe & Contrastive Analysis */}
        <div className="pt-2 grid grid-cols-1 sm:grid-cols-12 gap-3">
          <button
            onClick={handleTranscribe}
            disabled={(!audioBlob && !selectedFile) || isRecording || isTranscribing || isAnalyzing}
            className="sm:col-span-5 py-3.5 px-4 rounded-xl font-bold text-xs tracking-wide border border-cyan-500/40 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 transition-all flex items-center justify-center space-x-2 disabled:opacity-40"
          >
            {isTranscribing ? (
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-cyan-300 border-t-transparent rounded-full animate-spin" />
                <span>Transcribing (Groq Whisper STT)...</span>
              </div>
            ) : (
              <>
                <FileAudio className="w-4 h-4 text-cyan-400" />
                <span>Transcribe Audio (Groq Whisper STT)</span>
              </>
            )}
          </button>

          <button
            onClick={handleAnalyze}
            disabled={(!audioBlob && !selectedFile) || isRecording || isAnalyzing}
            className={`sm:col-span-7 py-3.5 rounded-xl font-bold text-sm tracking-wide shadow-xl transition-all duration-200 flex items-center justify-center space-x-2 ${
              isAnalyzing
                ? 'bg-brand-600 text-white cursor-wait'
                : !audioBlob && !selectedFile
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-brand-500 via-teal-400 to-cyan-500 text-slate-950 hover:brightness-110 glow-teal'
            }`}
          >
            {isAnalyzing ? (
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>{analysisStep}</span>
              </div>
            ) : (
              <>
                <Sparkles className="w-4 h-4 fill-current" />
                <span>ANALYZE SPEECH & GROUND FLAWS</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Complete Platform Capabilities & Live Showcase */}
      <div className="space-y-4 pt-4 border-t border-slate-800/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="text-xs uppercase font-semibold tracking-wider text-brand-400">
              Complete Platform Architecture <span aria-hidden="true">·</span> 9 Integrated Capabilities
            </div>
            <h2 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
              Explore All Platform Features
            </h2>
          </div>
          <span className="text-xs text-slate-400">
            Click any module to jump directly to its live interface
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Card 1: WaveSurfer & Flaw Grounding */}
          <div 
            onClick={() => { onSelectDemo('flagship'); onNavigateTab('report'); }}
            className="p-5 rounded-2xl glass-panel hover:border-brand-500/40 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-brand-500/15 border border-brand-500/30 flex items-center justify-center text-brand-400 mb-3 group-hover:scale-105 transition-transform">
                <AudioWaveform className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-brand-300 transition-colors">
                Temporal Flaw Grounding
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                WaveSurfer player with interactive timestamp pins for fillers, dead pauses, and disfluent speech markers.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-brand-400 font-medium">
              <span>Inspect Waveform</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2: Audio Transcription */}
          <div 
            onClick={() => {
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="p-5 rounded-2xl glass-panel hover:border-cyan-500/40 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3 group-hover:scale-105 transition-transform">
                <FileAudio className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                Gemini 3.5 Transcribe
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Direct microphone or audio file transcription using dedicated gemini-3.5-transcribe model with verbatim accuracy.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-cyan-400 font-medium">
              <span>Test Transcribe Above</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3: AI Speech Coach */}
          <div 
            onClick={() => onNavigateTab('coach')}
            className="p-5 rounded-2xl glass-panel hover:border-purple-500/40 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-3 group-hover:scale-105 transition-transform">
                <MessageSquare className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors">
                AI Speech Coach & Mentor
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Multi-turn conversation thread with role-specific system instructions, model switching (3.5-Flash, 3.1-Pro, 3.1-Lite), and physical vocal drills.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-purple-400 font-medium">
              <span>Open AI Coach</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 4: Google Search Grounding */}
          <div 
            onClick={() => onNavigateTab('coach')}
            className="p-5 rounded-2xl glass-panel hover:border-cyan-500/40 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3 group-hover:scale-105 transition-transform">
                <Search className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                Google Search Grounding
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Real-time web search grounding using gemini-3.5-flash to retrieve current 2026 executive speaking benchmarks with live citations.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-cyan-400 font-medium">
              <span>Try Search Grounding</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 5: Contrastive Calibration */}
          <div 
            onClick={() => onNavigateTab('compare')}
            className="p-5 rounded-2xl glass-panel hover:border-teal-500/40 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-400 mb-3 group-hover:scale-105 transition-transform">
                <GitCompare className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-teal-300 transition-colors">
                Contrastive Benchmarking
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Multi-bar distribution charts mathematically contrasting your metrics against empirical ideal and flawed exemplar distributions.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-teal-400 font-medium">
              <span>Compare Dimensions</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 6: Longitudinal Progress */}
          <div 
            onClick={() => onNavigateTab('progress')}
            className="p-5 rounded-2xl glass-panel hover:border-emerald-500/40 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-3 group-hover:scale-105 transition-transform">
                <TrendingUp className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
                Longitudinal Progress
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Continuous score trajectory tracking across practice sessions with dimension deltas and habit improvement analytics.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-emerald-400 font-medium">
              <span>View Progress Charts</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 7: Dataset & Exemplar Audio */}
          <div 
            onClick={() => onNavigateTab('dataset')}
            className="p-5 rounded-2xl glass-panel hover:border-blue-500/40 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 mb-3 group-hover:scale-105 transition-transform">
                <Database className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-blue-300 transition-colors">
                Exemplar Audio Corpus
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Listen directly to paired ideal vs flawed speech audio recordings and inspect transparent mathematical rubric weights.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-blue-400 font-medium">
              <span>Listen to Exemplars</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 8: Firebase Auth & Firestore Sync */}
          <div 
            className="p-5 rounded-2xl glass-panel hover:border-amber-500/40 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-3">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">
                Firebase Auth & Firestore
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Zero-trust user data isolation with Google Sign-In and real-time Firestore database persistence for sessions and chat history.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/60 text-xs text-amber-300/80 font-mono">
              {user ? `Connected: ${user.email || user.displayName}` : 'Sign in at top right to sync'}
            </div>
          </div>

          {/* Card 9: 8-Dimension Radar & Tips */}
          <div 
            onClick={() => { onSelectDemo('flagship'); onNavigateTab('report'); }}
            className="p-5 rounded-2xl glass-panel hover:border-teal-500/40 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-400 mb-3 group-hover:scale-105 transition-transform">
                <BarChart2 className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-teal-300 transition-colors">
                8-Dimension Speech Radar
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Polar radar breakdown of Clarity, Fluency, Pacing, Pauses, Fillers, Pronunciation, Confidence, and Vocabulary.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-teal-400 font-medium">
              <span>View Speech Radar</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
