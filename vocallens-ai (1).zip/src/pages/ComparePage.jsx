import React, { useEffect, useState, useRef } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  GitCompare,
  Info,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Clock,
  FileAudio,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Zap,
  Split,
  Eye,
  Check,
  Copy,
  TrendingUp,
} from 'lucide-react';
import { fetchBaseline } from '../api/client';

const FILLER_WORDS_LIST = [
  'um', 'uh', 'er', 'ah', 'like', 'basically', 'actually', 'literally',
  'you know', 'sort of', 'kind of', 'i mean', 'right', 'matlab', 'toh',
  'yaani', 'theek hai', 'hmm', 'uhh', 'umm', 'so yeah', 'well',
];

export default function ComparePage({ report, onNavigateToRecord }) {
  const [baseline, setBaseline] = useState(null);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState('side-by-side'); // 'side-by-side' | 'tabs'
  const [activeTab, setActiveTab] = useState('original'); // 'original' | 'ideal'

  // Audio 1: Original Audio state
  const [isOrigPlaying, setIsOrigPlaying] = useState(false);
  const [origCurrentTime, setOrigCurrentTime] = useState(0);
  const [origDuration, setOrigDuration] = useState(0);
  const [origPlaybackRate, setOrigPlaybackRate] = useState(1);
  const [isOrigMuted, setIsOrigMuted] = useState(false);
  const origAudioRef = useRef(null);

  // Audio 2: Ideal Audio state
  const [isIdealPlaying, setIsIdealPlaying] = useState(false);
  const [idealCurrentTime, setIdealCurrentTime] = useState(0);
  const [idealDuration, setIdealDuration] = useState(0);
  const [idealPlaybackRate, setIdealPlaybackRate] = useState(1);
  const [isIdealMuted, setIsIdealMuted] = useState(false);
  const idealAudioRef = useRef(null);

  const [copiedOrig, setCopiedOrig] = useState(false);
  const [copiedIdeal, setCopiedIdeal] = useState(false);

  useEffect(() => {
    fetchBaseline()
      .then((data) => {
        setBaseline(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  // Data resolution
  const originalAudioUrl = report?.audio_path || '/audio/demo_flawed.wav';
  const idealAudioUrl = report?.corrected_audio_path || '/audio/demo_flagship.wav';

  const originalTranscript =
    report?.transcript_text ||
    'Um, good morning everyone, like basically I wanted to talk about our project. And uh, we we built some stuff that works well.';

  const idealTranscript =
    report?.corrected_transcript_text ||
    'Good morning everyone. Today I am pleased to present the key milestones of our project. Over the past quarter, our engineering team has developed a scalable, high-performance architecture that delivers consistent results.';

  const originalWords = Array.isArray(report?.transcript_words) && report.transcript_words.length > 0
    ? report.transcript_words
    : originalTranscript.split(/\s+/).filter(Boolean).map((w, idx) => ({
        word: w,
        start: Math.round(idx * 0.45 * 100) / 100,
        end: Math.round((idx * 0.45 + 0.35) * 100) / 100,
        probability: idx % 4 === 0 ? 0.65 : 0.95,
      }));

  const flawEvents = Array.isArray(report?.flaw_events) ? report.flaw_events : [];

  // Helper to determine if a word is filler or unnecessary
  const isFillerWord = (w) => {
    const rawWord = typeof w === 'string' ? w : w.word || '';
    const clean = rawWord.toLowerCase().replace(/[^\w]/g, '');
    if (!clean) return false;

    if (FILLER_WORDS_LIST.includes(clean)) return true;

    if (typeof w === 'object' && flawEvents.length > 0) {
      const match = flawEvents.find(
        (f) =>
          (f.type === 'filler' || f.type === 'repetition') &&
          ((w.start >= (f.start ?? 0) - 0.15 && w.start <= (f.end ?? 0) + 0.15) ||
            (w.end >= (f.start ?? 0) - 0.15 && w.end <= (f.end ?? 0) + 0.15))
      );
      if (match) return true;
    }
    return false;
  };

  // Compute counts
  const totalOriginalWords = originalWords.length;
  const fillerCount = originalWords.filter(isFillerWord).length;
  const usefulCount = Math.max(0, totalOriginalWords - fillerCount);
  const efficiencyPercentage = totalOriginalWords > 0 ? Math.round((usefulCount / totalOriginalWords) * 100) : 100;

  // Audio 1 Controls
  const toggleOrigPlay = () => {
    if (!origAudioRef.current) return;
    if (isOrigPlaying) {
      origAudioRef.current.pause();
      setIsOrigPlaying(false);
    } else {
      if (isIdealPlaying && idealAudioRef.current) {
        idealAudioRef.current.pause();
        setIsIdealPlaying(false);
      }
      origAudioRef.current.play()
        .then(() => setIsOrigPlaying(true))
        .catch((e) => console.warn('Original audio play notice:', e));
    }
  };

  const handleOrigSeek = (timeSec) => {
    if (origAudioRef.current) {
      origAudioRef.current.currentTime = timeSec;
      setOrigCurrentTime(timeSec);
    }
  };

  // Audio 2 Controls
  const toggleIdealPlay = () => {
    if (!idealAudioRef.current) return;
    if (isIdealPlaying) {
      idealAudioRef.current.pause();
      setIsIdealPlaying(false);
    } else {
      if (isOrigPlaying && origAudioRef.current) {
        origAudioRef.current.pause();
        setIsOrigPlaying(false);
      }
      idealAudioRef.current.play()
        .then(() => setIsIdealPlaying(true))
        .catch((e) => console.warn('Ideal audio play notice:', e));
    }
  };

  const handleIdealSeek = (timeSec) => {
    if (idealAudioRef.current) {
      idealAudioRef.current.currentTime = timeSec;
      setIdealCurrentTime(timeSec);
    }
  };

  const formatTime = (secs) => {
    if (isNaN(secs) || secs === undefined || secs === null) return '00:00';
    const mins = Math.floor(secs / 60);
    const rem = Math.floor(secs % 60);
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  const dimensions = [
    'clarity',
    'fluency',
    'pace',
    'pauses',
    'fillers',
    'pronunciation',
    'confidence',
    'vocabulary',
  ];

  // Prepare comparison data for Recharts Bar Chart
  const chartData = dimensions.map((dim) => {
    const userScore = report?.dimension_scores?.[dim] !== undefined ? report.dimension_scores[dim] : 72;
    const idealMean = 92;
    const flawedMean = 25;

    return {
      dimension: dim.charAt(0).toUpperCase() + dim.slice(1),
      User: Number(Number(userScore || 0).toFixed(1)),
      IdealBenchmark: idealMean,
      FlawedBenchmark: flawedMean,
    };
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="text-xs uppercase font-semibold tracking-wider text-cyan-400 flex items-center space-x-2">
            <GitCompare className="w-4 h-4" />
            <span>Dual-Distribution Benchmarking · Audio & Transcript Contrast</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-white mt-1.5">
            Original vs. Ideal Exemplar Comparison
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Compare your original voice recording and transcript against calibrated ideal exemplars. Unnecessary filler words are highlighted in red while purposeful content words remain in green.
          </p>
        </div>

        {/* View Toggle */}
        <div className="flex items-center space-x-2 bg-slate-900/90 border border-slate-800 p-1 rounded-xl text-xs">
          <button
            onClick={() => setViewMode('side-by-side')}
            className={`px-3 py-1.5 rounded-lg font-semibold flex items-center space-x-1.5 transition-all ${
              viewMode === 'side-by-side'
                ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Split className="w-3.5 h-3.5" />
            <span>Side-by-Side</span>
          </button>
          <button
            onClick={() => setViewMode('tabs')}
            className={`px-3 py-1.5 rounded-lg font-semibold flex items-center space-x-1.5 transition-all ${
              viewMode === 'tabs'
                ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Tabbed View</span>
          </button>
        </div>
      </div>

      {/* Metric Transformation Summary Header */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl glass-panel border border-slate-800/90 bg-gradient-to-br from-slate-900/90 to-slate-950/90">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Overall Calibration</div>
          <div className="mt-1 flex items-baseline space-x-2">
            <span className="text-xl font-bold font-mono text-white">{Number(report?.overall_score || 51.8).toFixed(1)}</span>
            <span className="text-xs text-slate-500">vs</span>
            <span className="text-xl font-bold font-mono text-emerald-400">89.5</span>
          </div>
          <div className="text-[10px] text-brand-400 mt-1">User Score → Ideal Exemplar</div>
        </div>

        <div className="p-4 rounded-xl glass-panel border border-rose-500/20 bg-rose-500/5">
          <div className="text-[11px] font-semibold text-rose-300 uppercase tracking-wider flex items-center space-x-1">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span>Fillers in Original</span>
          </div>
          <div className="mt-1 flex items-baseline space-x-2">
            <span className="text-xl font-bold font-mono text-rose-400">{fillerCount}</span>
            <span className="text-xs text-slate-400">({report?.raw_metrics?.fillers || '18.9'}/min)</span>
          </div>
          <div className="text-[10px] text-rose-300/80 mt-1">Highlighted in RED below</div>
        </div>

        <div className="p-4 rounded-xl glass-panel border border-emerald-500/20 bg-emerald-500/5">
          <div className="text-[11px] font-semibold text-emerald-300 uppercase tracking-wider flex items-center space-x-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Useful Content Words</span>
          </div>
          <div className="mt-1 flex items-baseline space-x-2">
            <span className="text-xl font-bold font-mono text-emerald-400">{usefulCount}</span>
            <span className="text-xs text-slate-400">({efficiencyPercentage}% useful)</span>
          </div>
          <div className="text-[10px] text-emerald-300/80 mt-1">Highlighted in GREEN below</div>
        </div>

        <div className="p-4 rounded-xl glass-panel border border-cyan-500/20 bg-cyan-500/5">
          <div className="text-[11px] font-semibold text-cyan-300 uppercase tracking-wider flex items-center space-x-1">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Exemplar Target</span>
          </div>
          <div className="mt-1 flex items-baseline space-x-2">
            <span className="text-xl font-bold font-mono text-cyan-300">0</span>
            <span className="text-xs text-slate-400">fillers · 142 WPM</span>
          </div>
          <div className="text-[10px] text-cyan-300/80 mt-1">100% articulate delivery</div>
        </div>
      </div>

      {/* Tab Selector when in Tabbed View */}
      {viewMode === 'tabs' && (
        <div className="flex items-center space-x-2 border-b border-slate-800 pb-2 text-xs">
          <button
            onClick={() => setActiveTab('original')}
            className={`px-4 py-2 rounded-xl font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'original'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span>Original Delivery ({fillerCount} Fillers in Red · {usefulCount} Useful in Green)</span>
          </button>
          <button
            onClick={() => setActiveTab('ideal')}
            className={`px-4 py-2 rounded-xl font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'ideal'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Ideal Exemplar Delivery (Zero Fillers · 89.5 Score)</span>
          </button>
        </div>
      )}

      {/* Main Comparison Container */}
      <div className={`grid gap-6 ${viewMode === 'side-by-side' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
        {/* CARD 1: Original Audio & Color-Coded Transcript */}
        {(viewMode === 'side-by-side' || activeTab === 'original') && (
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 bg-gradient-to-b from-slate-900/90 via-slate-950/80 to-slate-900/90 space-y-5 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Card Title & Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2.5">
                  <div className="w-3 h-3 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50" />
                  <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                      Original Voice Recording
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      User speech with detected disfluencies and fillers
                    </p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[11px] bg-rose-500/10 text-rose-300 border border-rose-500/30 font-semibold font-mono">
                  {report?.band || 'Needs work'} · {Number(report?.overall_score || 51.8).toFixed(1)}/100
                </span>
              </div>

              {/* Hidden Audio Element */}
              <audio
                ref={origAudioRef}
                src={originalAudioUrl}
                onTimeUpdate={() => {
                  if (origAudioRef.current) {
                    setOrigCurrentTime(origAudioRef.current.currentTime);
                    if (origAudioRef.current.duration && !isNaN(origAudioRef.current.duration)) {
                      setOrigDuration(origAudioRef.current.duration);
                    }
                  }
                }}
                onLoadedMetadata={() => {
                  if (origAudioRef.current) {
                    setOrigDuration(origAudioRef.current.duration);
                  }
                }}
                onEnded={() => {
                  setIsOrigPlaying(false);
                  setOrigCurrentTime(0);
                }}
              />

              {/* Audio Player Controls */}
              <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={toggleOrigPlay}
                      className="w-10 h-10 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center font-bold shadow-lg shadow-rose-600/30 transition-all flex-shrink-0"
                      title={isOrigPlaying ? 'Pause Original' : 'Play Original'}
                    >
                      {isOrigPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
                    </button>

                    <div>
                      <div className="text-xs font-semibold text-white flex items-center space-x-1.5">
                        <FileAudio className="w-3.5 h-3.5 text-rose-400" />
                        <span>Original Audio Track</span>
                      </div>
                      <div className="font-mono text-xs text-rose-300">
                        {formatTime(origCurrentTime)} / {formatTime(origDuration || report?.duration || 25)}
                      </div>
                    </div>
                  </div>

                  {/* Playback rate & Mute */}
                  <div className="flex items-center space-x-2">
                    <select
                      value={origPlaybackRate}
                      onChange={(e) => {
                        const r = parseFloat(e.target.value);
                        setOrigPlaybackRate(r);
                        if (origAudioRef.current) origAudioRef.current.playbackRate = r;
                      }}
                      className="bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-[10px] text-slate-300 focus:outline-none"
                    >
                      <option value="1">1.0x</option>
                      <option value="1.25">1.25x</option>
                      <option value="1.5">1.5x</option>
                    </select>

                    <button
                      onClick={() => {
                        const nextMute = !isOrigMuted;
                        setIsOrigMuted(nextMute);
                        if (origAudioRef.current) origAudioRef.current.muted = nextMute;
                      }}
                      className="text-slate-400 hover:text-slate-200"
                    >
                      {isOrigMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Progress bar scrubber */}
                <input
                  type="range"
                  min="0"
                  max={origDuration || report?.duration || 25}
                  step="0.05"
                  value={origCurrentTime}
                  onChange={(e) => handleOrigSeek(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
                />
              </div>

              {/* Color Code Legend */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80 text-[11px]">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
                    <span className="text-rose-300 font-semibold">Red = Filler / Unnecessary ({fillerCount})</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
                    <span className="text-emerald-300 font-semibold">Green = Useful Speech ({usefulCount})</span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(originalTranscript);
                    setCopiedOrig(true);
                    setTimeout(() => setCopiedOrig(false), 2000);
                  }}
                  className="text-slate-400 hover:text-slate-200 flex items-center space-x-1 text-[10px]"
                >
                  {copiedOrig ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedOrig ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Color-Coded Word-Level Transcript */}
              <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 max-h-72 overflow-y-auto space-y-2">
                <div className="flex flex-wrap gap-1.5 text-xs leading-relaxed">
                  {originalWords.map((w, idx) => {
                    const filler = isFillerWord(w);
                    const isCurrent = origCurrentTime >= (w.start ?? 0) && origCurrentTime <= (w.end ?? 0) + 0.2;

                    return (
                      <button
                        key={`${w.word}-${idx}`}
                        onClick={() => handleOrigSeek(w.start ?? 0)}
                        className={`px-2 py-1 rounded-md transition-all duration-150 text-left font-sans cursor-pointer group relative ${
                          filler
                            ? 'bg-rose-500/25 text-rose-200 border border-rose-500/50 font-bold hover:bg-rose-500/40 shadow-sm shadow-rose-950/50'
                            : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-medium hover:bg-emerald-500/25'
                        } ${isCurrent ? 'ring-2 ring-white scale-105 shadow-md' : ''}`}
                        title={`[${w.start}s - ${w.end}s] ${
                          filler ? 'Filler / Disfluent word (Eliminate)' : 'Useful content word'
                        } · Click to jump audio`}
                      >
                        <span className={filler ? 'line-through decoration-rose-400/60 mr-1 opacity-90' : ''}>
                          {w.word}
                        </span>
                        {filler && (
                          <span className="text-[9px] uppercase px-1 py-0.2 rounded bg-rose-600/80 text-white font-mono ml-0.5">
                            filler
                          </span>
                        )}
                        <span className="text-[8px] font-mono opacity-40 group-hover:opacity-100 ml-1 text-slate-400">
                          {w.start}s
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Diagnostic Badges Footer */}
            <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
              <span className="flex items-center space-x-1 text-rose-300">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                <span>Identified {fillerCount} verbal crutches to eliminate</span>
              </span>
              <span className="font-mono text-slate-400">Pace: {report?.wpm || '112.5'} WPM</span>
            </div>
          </div>
        )}

        {/* CARD 2: Ideal Exemplar Audio & Refined Transcript */}
        {(viewMode === 'side-by-side' || activeTab === 'ideal') && (
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 bg-gradient-to-b from-slate-900/90 via-slate-950/80 to-slate-900/90 space-y-5 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Card Title & Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2.5">
                  <div className="w-3 h-3 rounded-full bg-emerald-400 shadow-sm shadow-emerald-500/50" />
                  <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                      Ideal Speech Exemplar
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Cleaned cadence with zero verbal fillers and steady 140 WPM pacing
                    </p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[11px] bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-semibold font-mono">
                  Exemplar Benchmark · 89.5/100
                </span>
              </div>

              {/* Hidden Audio Element */}
              <audio
                ref={idealAudioRef}
                src={idealAudioUrl}
                onTimeUpdate={() => {
                  if (idealAudioRef.current) {
                    setIdealCurrentTime(idealAudioRef.current.currentTime);
                    if (idealAudioRef.current.duration && !isNaN(idealAudioRef.current.duration)) {
                      setIdealDuration(idealAudioRef.current.duration);
                    }
                  }
                }}
                onLoadedMetadata={() => {
                  if (idealAudioRef.current) {
                    setIdealDuration(idealAudioRef.current.duration);
                  }
                }}
                onEnded={() => {
                  setIsIdealPlaying(false);
                  setIdealCurrentTime(0);
                }}
              />

              {/* Audio Player Controls */}
              <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={toggleIdealPlay}
                      className="w-10 h-10 rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 hover:brightness-110 text-slate-950 flex items-center justify-center font-bold shadow-lg shadow-emerald-500/30 transition-all flex-shrink-0"
                      title={isIdealPlaying ? 'Pause Ideal' : 'Play Ideal Exemplar'}
                    >
                      {isIdealPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
                    </button>

                    <div>
                      <div className="text-xs font-semibold text-white flex items-center space-x-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Ideal Audio Exemplar</span>
                      </div>
                      <div className="font-mono text-xs text-emerald-300">
                        {formatTime(idealCurrentTime)} / {formatTime(idealDuration || 22)}
                      </div>
                    </div>
                  </div>

                  {/* Playback rate & Mute */}
                  <div className="flex items-center space-x-2">
                    <select
                      value={idealPlaybackRate}
                      onChange={(e) => {
                        const r = parseFloat(e.target.value);
                        setIdealPlaybackRate(r);
                        if (idealAudioRef.current) idealAudioRef.current.playbackRate = r;
                      }}
                      className="bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-[10px] text-slate-300 focus:outline-none"
                    >
                      <option value="1">1.0x</option>
                      <option value="1.25">1.25x</option>
                      <option value="1.5">1.5x</option>
                    </select>

                    <button
                      onClick={() => {
                        const nextMute = !isIdealMuted;
                        setIsIdealMuted(nextMute);
                        if (idealAudioRef.current) idealAudioRef.current.muted = nextMute;
                      }}
                      className="text-slate-400 hover:text-slate-200"
                    >
                      {isIdealMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Progress bar scrubber */}
                <input
                  type="range"
                  min="0"
                  max={idealDuration || 22}
                  step="0.05"
                  value={idealCurrentTime}
                  onChange={(e) => handleIdealSeek(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
                />
              </div>

              {/* Exemplar Specs Banner */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-[11px] text-emerald-300 font-medium">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Flaw-Free Exemplar · 0 Fillers · Optimal Pacing</span>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(idealTranscript);
                    setCopiedIdeal(true);
                    setTimeout(() => setCopiedIdeal(false), 2000);
                  }}
                  className="text-slate-400 hover:text-slate-200 flex items-center space-x-1 text-[10px]"
                >
                  {copiedIdeal ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedIdeal ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Ideal Transcript Display */}
              <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 max-h-72 overflow-y-auto space-y-2">
                <div className="flex flex-wrap gap-1.5 text-xs leading-relaxed">
                  {idealTranscript.split(/\s+/).filter(Boolean).map((w, idx) => {
                    return (
                      <span
                        key={`${w}-${idx}`}
                        className="px-2 py-1 rounded-md bg-teal-500/10 text-teal-200 border border-teal-500/20 font-medium inline-block shadow-sm"
                      >
                        {w}
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Exemplar Key Gains Footer */}
            <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
              <span className="flex items-center space-x-1 text-emerald-300">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>100% fluent declarative structure</span>
              </span>
              <span className="font-mono text-emerald-400">Pace: 142.0 WPM</span>
            </div>
          </div>
        )}
      </div>

      {/* Key Improvement Highlights Callout */}
      <div className="p-6 rounded-2xl glass-panel bg-gradient-to-r from-brand-950/30 via-slate-900/60 to-cyan-950/30 border border-brand-500/20 space-y-3">
        <div className="flex items-center space-x-2 text-brand-300">
          <Sparkles className="w-4 h-4 text-brand-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider">
            Key Transformations to Bridge the Exemplar Gap
          </h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1">
            <span className="font-semibold text-rose-300 flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-rose-400" />
              <span>1. Purge Red Verbal Fillers</span>
            </span>
            <p className="text-[11px] text-slate-400">
              Replace vocal crutches (<em>um, like, basically</em>) with calm 0.5s silent breaths to project command.
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1">
            <span className="font-semibold text-amber-300 flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span>2. Eliminate Stuttered Restarts</span>
            </span>
            <p className="text-[11px] text-slate-400">
              Commit forward decisively on initial syllables without double-starting verbs.
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1">
            <span className="font-semibold text-emerald-300 flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>3. Anchor 135–150 WPM Cadence</span>
            </span>
            <p className="text-[11px] text-slate-400">
              Maintain an authoritative rhythm with downward pitch inflections at complete sentences.
            </p>
          </div>
        </div>
      </div>

      {/* Comparison Multi-Bar Chart */}
      <div className="p-6 rounded-2xl glass-panel space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold tracking-wider uppercase text-slate-300">
              Dimension Contrast: User vs. Ideal vs. Flawed Benchmark
            </h3>
            <p className="text-xs text-slate-400">Mathematical separation across all 8 empirical speech dimensions.</p>
          </div>
        </div>

        <div className="w-full h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 20, right: 20, left: -10, bottom: 20 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="dimension" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis domain={[0, 100]} tick={{ fill: '#64748b', fontSize: 11 }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '0.75rem',
                  fontSize: '12px',
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
              <Bar dataKey="User" fill="#14b8a6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="IdealBenchmark" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="FlawedBenchmark" fill="#f43f5e" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Detailed Metrics Table */}
      <div className="p-6 rounded-2xl glass-panel space-y-4">
        <h3 className="text-xs font-semibold tracking-wider uppercase text-slate-300">
          Comprehensive Metric Distribution Table
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-3">Dimension</th>
                <th className="py-3 px-3">User Raw Value</th>
                <th className="py-3 px-3">Ideal Group Mean</th>
                <th className="py-3 px-3">Flawed Group Mean</th>
                <th className="py-3 px-3">Contrastive Score</th>
                <th className="py-3 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {dimensions.map((dim) => {
                const userScore = report?.dimension_scores?.[dim] || 70;
                const userRaw = report?.raw_metrics?.[dim] !== undefined ? report.raw_metrics[dim] : '—';
                const idealM = baseline?.ideal?.[dim]?.mean !== undefined ? baseline.ideal[dim].mean : '—';
                const flawedM = baseline?.flawed?.[dim]?.mean !== undefined ? baseline.flawed[dim].mean : '—';

                return (
                  <tr key={dim} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-3 px-3 font-bold text-white capitalize">{dim}</td>
                    <td className="py-3 px-3 font-mono text-brand-300">{userRaw}</td>
                    <td className="py-3 px-3 font-mono text-emerald-400">{idealM}</td>
                    <td className="py-3 px-3 font-mono text-rose-400">{flawedM}</td>
                    <td className="py-3 px-3 font-bold">
                      <span
                        className={`px-2 py-0.5 rounded text-xs ${
                          userScore >= 80
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : userScore >= 60
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {Number(userScore || 0).toFixed(1)} / 100
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      {userScore >= 80 ? (
                        <span className="text-emerald-400 font-semibold flex items-center space-x-1">
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>Exemplar Level</span>
                        </span>
                      ) : userScore >= 60 ? (
                        <span className="text-amber-400 font-medium">Developing</span>
                      ) : (
                        <span className="text-rose-400 font-medium">Flawed Gap</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
