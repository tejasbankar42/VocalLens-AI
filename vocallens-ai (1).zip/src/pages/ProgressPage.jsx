import React, { useEffect, useState, useMemo, useRef } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
} from 'recharts';
import {
  TrendingUp,
  Award,
  Calendar,
  ChevronRight,
  Sparkles,
  CheckCircle2,
  Database,
  Download,
  Upload,
  Trash2,
  RefreshCw,
  Search,
  Filter,
  ArrowUpRight,
  Zap,
  Volume2,
  ShieldCheck,
  FileText,
} from 'lucide-react';
import { fetchProgress } from '../api/client';
import {
  getLocalSessions,
  deleteLocalSession,
  exportSessionsAsJSON,
  importSessionsFromJSON,
  resetToDemoMilestones,
  computeLongitudinalProgress,
  updateSessionMetadata,
} from '../lib/localStorageService';

export default function ProgressPage({ onSelectSession }) {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState('ALL');
  const [notification, setNotification] = useState('');
  const fileInputRef = useRef(null);

  // Load from local storage and fallback/sync with server progress
  const loadSessionsData = async () => {
    try {
      const local = getLocalSessions();
      if (local && local.length > 0) {
        setSessions(local);
        setLoading(false);
      } else {
        // Fallback to API if local is empty
        const serverData = await fetchProgress();
        if (serverData?.recent_sessions?.length > 0) {
          setSessions(serverData.recent_sessions);
        }
        setLoading(false);
      }
    } catch (err) {
      console.warn('Progress load notice:', err);
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSessionsData();
  }, []);

  const showNotification = (msg) => {
    setNotification(msg);
    setTimeout(() => setNotification(''), 3000);
  };

  // Compute longitudinal progress analytics
  const analytics = useMemo(() => {
    return computeLongitudinalProgress(sessions);
  }, [sessions]);

  // Handle single session deletion
  const handleDeleteSession = (e, sessionId) => {
    e.stopPropagation();
    if (window.confirm('Delete this recording and its analysis from local storage?')) {
      deleteLocalSession(sessionId);
      const updated = getLocalSessions();
      setSessions(updated);
      showNotification('Session deleted from local storage.');
    }
  };

  // Handle export
  const handleExport = () => {
    exportSessionsAsJSON();
    showNotification('Exported all recordings and metadata as JSON.');
  };

  // Handle file import
  const handleFileImport = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const merged = importSessionsFromJSON(event.target.result);
        setSessions(merged);
        showNotification(`Successfully imported ${merged.length} sessions.`);
      } catch (err) {
        alert('Invalid JSON file format. Please upload a valid VocalLens export file.');
      }
    };
    reader.readAsText(file);
  };

  // Handle reset to demo milestone track
  const handleResetMilestones = () => {
    if (window.confirm('Reset local storage back to standard milestone progression?')) {
      const reset = resetToDemoMilestones();
      setSessions(reset);
      showNotification('Reset to default milestone track.');
    }
  };

  // Filtered sessions for history table
  const filteredSessions = useMemo(() => {
    return sessions.filter((s) => {
      const matchesSearch =
        searchQuery === '' ||
        (s.filename || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (s.transcript_text || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (s.tag || '').toLowerCase().includes(searchQuery.toLowerCase());

      const matchesTag =
        selectedTag === 'ALL' ||
        (s.tag || 'Recording').toUpperCase() === selectedTag.toUpperCase() ||
        (s.band || '').toUpperCase() === selectedTag.toUpperCase();

      return matchesSearch && matchesTag;
    });
  }, [sessions, searchQuery, selectedTag]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto py-20 text-center text-slate-400 text-sm">
        <div className="w-8 h-8 border-2 border-brand-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <span>Loading historical progress & local storage analytics...</span>
      </div>
    );
  }

  const {
    total_sessions = 0,
    average_score = 0,
    highest_score = 0,
    most_improved_dimension = 'Clarity',
    improvement_delta = 0,
    filler_reduction_pct = 0,
    score_history = [],
  } = analytics;

  // Compare first baseline vs latest session for delta display
  const firstSession = sessions[sessions.length - 1];
  const latestSession = sessions[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-slate-900 border border-brand-500/40 text-brand-300 text-xs shadow-2xl flex items-center space-x-2 animate-in slide-in-from-bottom-3">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Header & Local Storage Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs uppercase font-semibold tracking-wider text-emerald-400">
              Longitudinal Analytics <span aria-hidden="true">·</span> Local Storage System
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-mono">
              Offline Persistent
            </span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-white mt-1.5">
            Speech Improvement Trajectory
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            All your voice recordings, temporal flaw markers, and acoustic dimension scores are saved in local storage.
          </p>
        </div>

        {/* Local Storage System Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExport}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-medium flex items-center space-x-1.5 transition-colors shadow-sm"
            title="Export all saved sessions to a JSON file"
          >
            <Download className="w-3.5 h-3.5 text-brand-400" />
            <span>Export Data</span>
          </button>

          <button
            onClick={() => fileInputRef.current && fileInputRef.current.click()}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-medium flex items-center space-x-1.5 transition-colors shadow-sm"
            title="Import previously exported session backups"
          >
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            <span>Import Data</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleFileImport}
            className="hidden"
          />

          <button
            onClick={handleResetMilestones}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 text-xs font-medium flex items-center space-x-1.5 transition-colors shadow-sm"
            title="Reset to 10-day milestone standard"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Milestones</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl glass-panel flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Practice Sessions</span>
            <Database className="w-4 h-4 text-slate-500" />
          </div>
          <div className="my-2">
            <span className="text-3xl font-black text-white">{total_sessions}</span>
            <span className="text-xs text-slate-500 ml-1.5">recordings saved</span>
          </div>
          <p className="text-[11px] text-slate-400">Saved in browser localStorage</p>
        </div>

        <div className="p-5 rounded-2xl glass-panel flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Average Score</span>
            <Award className="w-4 h-4 text-brand-400" />
          </div>
          <div className="my-2">
            <span className="text-3xl font-black text-brand-300">{average_score}</span>
            <span className="text-xs text-slate-400 ml-1">/ 100</span>
          </div>
          <p className="text-[11px] text-slate-400">Across all recorded sessions</p>
        </div>

        <div className="p-5 rounded-2xl glass-panel flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Personal Best</span>
            <Zap className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="my-2">
            <span className="text-3xl font-black text-emerald-400">{highest_score}</span>
            <span className="text-xs text-slate-400 ml-1">/ 100</span>
          </div>
          <p className="text-[11px] text-emerald-400 font-medium">Flagship session standard</p>
        </div>

        <div className="p-5 rounded-2xl glass-panel bg-gradient-to-br from-brand-950/60 to-emerald-950/40 border border-brand-500/30 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-brand-300 flex items-center space-x-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Overall Growth</span>
            </span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="my-2">
            <span className="text-3xl font-black text-white">
              {improvement_delta >= 0 ? `+${improvement_delta}` : improvement_delta}
            </span>
            <span className="text-xs font-bold text-emerald-300 ml-1.5">pts</span>
          </div>
          <p className="text-[11px] text-slate-300">
            {filler_reduction_pct > 0 ? `${filler_reduction_pct}% filler word reduction` : `Growth in ${most_improved_dimension}`}
          </p>
        </div>
      </div>

      {/* Baseline vs Latest Comparison Banner */}
      {firstSession && latestSession && firstSession.id !== latestSession.id && (
        <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-brand-950/40 to-slate-900 border border-brand-500/30 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Trajectory Transformation: Baseline vs Latest Practice
              </h3>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">
              {new Date(firstSession.created_at).toLocaleDateString()} ➔ {new Date(latestSession.created_at).toLocaleDateString()}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Overall Score</span>
              <div className="flex items-baseline space-x-2 mt-1">
                <span className="text-slate-400 font-mono line-through">{firstSession.overall_score}</span>
                <span className="text-lg font-extrabold text-emerald-400 font-mono">{latestSession.overall_score}</span>
                <span className="text-[10px] font-bold text-emerald-300">
                  +{Math.round((latestSession.overall_score - firstSession.overall_score) * 10) / 10}
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Filler Words Count</span>
              <div className="flex items-baseline space-x-2 mt-1">
                <span className="text-rose-400 font-mono">{firstSession.filler_count}</span>
                <span className="text-slate-400">➔</span>
                <span className="text-lg font-extrabold text-emerald-400 font-mono">{latestSession.filler_count}</span>
                <span className="text-[10px] font-bold text-emerald-300">
                  {firstSession.filler_count > 0
                    ? `-${Math.round(((firstSession.filler_count - latestSession.filler_count) / firstSession.filler_count) * 100)}%`
                    : '0'}
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Hesitation Pauses (&gt;1.2s)</span>
              <div className="flex items-baseline space-x-2 mt-1">
                <span className="text-amber-400 font-mono">{firstSession.pause_count}</span>
                <span className="text-slate-400">➔</span>
                <span className="text-lg font-extrabold text-teal-300 font-mono">{latestSession.pause_count}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Speaking Cadence (WPM)</span>
              <div className="flex items-baseline space-x-2 mt-1">
                <span className="text-slate-400 font-mono">{firstSession.wpm}</span>
                <span className="text-slate-400">➔</span>
                <span className="text-lg font-extrabold text-cyan-300 font-mono">{latestSession.wpm}</span>
                <span className="text-[10px] text-slate-500">ideal: 130-155</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Progress Line Chart */}
      <div className="p-6 rounded-2xl glass-panel space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-xs font-semibold tracking-wider uppercase text-slate-300">
              Communication Score Growth Over Time
            </h3>
            <p className="text-xs text-slate-400">Progressive improvement trajectory plotted across saved recordings.</p>
          </div>
          <div className="flex items-center space-x-2 text-xs">
            <span className="flex items-center space-x-1 text-slate-400">
              <span className="w-3 h-3 rounded-full bg-brand-400 inline-block" />
              <span>Overall Score</span>
            </span>
          </div>
        </div>

        <div className="w-full h-72">
          {score_history.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={score_history} margin={{ top: 20, right: 20, left: -10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <YAxis domain={[30, 100]} tick={{ fill: '#64748b', fontSize: 11 }} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 shadow-xl text-xs space-y-1">
                          <p className="font-bold text-white">{data.filename}</p>
                          <p className="text-slate-400 text-[11px]">{data.fullDate}</p>
                          <div className="pt-1.5 border-t border-slate-800 grid grid-cols-2 gap-x-3 gap-y-1">
                            <span className="text-brand-300 font-bold">Score: {data.score} / 100</span>
                            <span className="text-cyan-300">WPM: {data.wpm}</span>
                            <span className="text-rose-300">Fillers: {data.fillers}</span>
                            <span className="text-amber-300">Pauses: {data.pauses}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="#14b8a6"
                  strokeWidth={3}
                  dot={{ r: 5, fill: '#14b8a6', strokeWidth: 2, stroke: '#0f172a' }}
                  activeDot={{ r: 7, fill: '#2dd4bf' }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-slate-500">
              No historical data available. Record your first session to initiate tracking.
            </div>
          )}
        </div>
      </div>

      {/* Session History Table & Search / Filter Controls */}
      <div className="p-6 rounded-2xl glass-panel space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2">
          <div>
            <h3 className="text-xs font-semibold tracking-wider uppercase text-slate-300">
              Practice Session History & Metadata
            </h3>
            <p className="text-xs text-slate-400">
              {filteredSessions.length} of {sessions.length} saved recording sessions
            </p>
          </div>

          {/* Search & Tag Filter */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search recordings..."
                className="pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-brand-400 w-44 sm:w-56"
              />
            </div>

            <select
              value={selectedTag}
              onChange={(e) => setSelectedTag(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-brand-400"
            >
              <option value="ALL">All Tags</option>
              <option value="EXCELLENT">Excellent (80+)</option>
              <option value="GOOD">Good (65-79)</option>
              <option value="NEEDS WORK">Needs Work (&lt;65)</option>
              <option value="BASELINE">Baseline</option>
              <option value="PRACTICE">Practice</option>
              <option value="MASTERY">Mastery</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-3">Session & Recording</th>
                <th className="py-3 px-3">Score</th>
                <th className="py-3 px-3">Band</th>
                <th className="py-3 px-3">WPM</th>
                <th className="py-3 px-3">Fillers</th>
                <th className="py-3 px-3">Pauses</th>
                <th className="py-3 px-3">Tag / Notes</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredSessions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500 text-xs italic">
                    No matching sessions found in local storage.
                  </td>
                </tr>
              ) : (
                filteredSessions.map((s) => (
                  <tr
                    key={s.id || s.session_id}
                    onClick={() => onSelectSession(s.id || s.session_id)}
                    className="hover:bg-slate-900/60 cursor-pointer transition-colors group"
                  >
                    <td className="py-3 px-3">
                      <span className="font-bold text-white group-hover:text-brand-300 transition-colors block">
                        {s.filename}
                      </span>
                      <div className="flex items-center space-x-2 text-[10px] text-slate-500 font-mono mt-0.5">
                        <span>{new Date(s.created_at).toLocaleDateString()}</span>
                        <span>·</span>
                        <span>{s.duration}s</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-bold font-mono text-brand-300 text-sm">
                      {s.overall_score}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                          s.band === 'Excellent'
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            : s.band === 'Good'
                            ? 'bg-teal-500/15 text-teal-300 border border-teal-500/30'
                            : s.band === 'Needs work'
                            ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                            : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        {s.band}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono">{s.wpm}</td>
                    <td className="py-3 px-3 font-mono">
                      <span className={s.filler_count > 3 ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                        {s.filler_count}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono">
                      <span className={s.pause_count > 3 ? 'text-amber-400' : 'text-slate-300'}>
                        {s.pause_count}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-[11px] text-slate-400 block max-w-xs truncate">
                        {s.notes || s.tag || 'Voice Recording'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="inline-flex items-center space-x-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => onSelectSession(s.id || s.session_id)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-brand-300 font-medium text-xs transition-colors flex items-center space-x-1"
                        >
                          <span>Review</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => handleDeleteSession(e, s.id || s.session_id)}
                          className="p-1 rounded-lg hover:bg-rose-500/20 text-slate-500 hover:text-rose-400 transition-colors"
                          title="Delete from local storage"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
