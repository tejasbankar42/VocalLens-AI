import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  Send,
  Sparkles,
  Bot,
  User,
  Search,
  Zap,
  Brain,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  BookOpen,
  HelpCircle,
  Mic,
  MicOff,
  Radio,
  Volume2,
  VolumeX,
  AudioWaveform,
  X,
  Play,
  Pause,
} from 'lucide-react';
import { sendChatMessage, sendLiveVoiceMessage, transcribeAudio } from '../api/client';
import { db } from '../lib/firebase';
import { collection, addDoc, query, orderBy, onSnapshot } from 'firebase/firestore';

export default function CoachChatPage({ user }) {
  const [messages, setMessages] = useState([
    {
      id: 'welcome-1',
      role: 'assistant',
      content: `Hello! I am your **VocalLens AI Coach** — powered by **gemini-3.8-live** for real-time voice coaching and **gemini-3.5-flash** with Google Search Grounding.

I can help you:
- **Have real-time voice conversations** with model **gemini-3.8-live** (click "Live Voice Mode" above)
- **Transcribe microphone speech** with model **gemini-3.5-transcribe**
- **Diagnose specific flaws** (filler words, disfluent restarts, awkward silences, monotone pitch)
- **Practice tactical vocal drills** (The Cork Drill, Pause-and-Breathe, 140 BPM metronome cadence)
- **Search live benchmarks** with Google Search Grounding for current industry standards.

What would you like to work on today?`,
      modelUsed: 'gemini-3.8-live / gemini-3.5-flash',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [modelType, setModelType] = useState('general'); // 'general' | 'complex' | 'fast'
  const [useSearch, setUseSearch] = useState(false);

  // Live Voice Mode (gemini-3.8-live) States
  const [isLiveVoiceOpen, setIsLiveVoiceOpen] = useState(false);
  const [isLiveListening, setIsLiveListening] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [liveCoachResponse, setLiveCoachResponse] = useState('');
  const [isLiveThinking, setIsLiveThinking] = useState(false);
  const [isLiveSpeaking, setIsLiveSpeaking] = useState(false);

  // Microphone Dictation / Transcribe State (gemini-3.5-transcribe)
  const [isDictating, setIsDictating] = useState(false);

  const messagesEndRef = useRef(null);
  const recognitionRef = useRef(null);
  const liveAudioPlayerRef = useRef(null);

  // Auto-scroll to bottom of thread
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Sync with Firestore if authenticated
  useEffect(() => {
    if (!user) return;

    try {
      const messagesRef = collection(db, 'users', user.uid, 'chat_messages');
      const q = query(messagesRef, orderBy('createdAt', 'asc'));

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const loaded = snapshot.docs.map((doc) => {
              const data = doc.data();
              return {
                id: doc.id,
                role: data.role,
                content: data.content,
                modelUsed: data.modelUsed,
                groundingMetadata: data.groundingMetadata,
                timestamp: new Date(data.createdAt).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                }),
              };
            });
            setMessages(loaded);
          }
        },
        (err) => {
          console.warn('Firestore chat listener notice:', err);
        }
      );

      return () => unsubscribe();
    } catch (e) {
      console.warn('Firestore chat listener initialization:', e);
    }
  }, [user]);

  // Clean up recognition on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, []);

  const handleSend = async (textToSend) => {
    const text = textToSend || input;
    if (!text.trim() || isLoading) return;

    const userMsg = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput('');
    setIsLoading(true);

    // Save user message to Firestore if authenticated
    if (user) {
      try {
        await addDoc(collection(db, 'users', user.uid, 'chat_messages'), {
          messageId: userMsg.id,
          userId: user.uid,
          role: 'user',
          content: userMsg.content,
          modelUsed: modelType,
          createdAt: new Date().toISOString(),
        });
      } catch (e) {
        console.warn('Error persisting user chat message to Firestore:', e);
      }
    }

    try {
      // Send conversation history to backend Gemini endpoint
      const response = await sendChatMessage(
        newHistory.map((m) => ({ role: m.role, content: m.content })),
        modelType,
        useSearch
      );

      const assistantMsg = {
        id: 'msg-' + (Date.now() + 1),
        role: 'assistant',
        content: response.content,
        modelUsed: response.modelUsed,
        groundingMetadata: response.groundingMetadata,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Save assistant response to Firestore if authenticated
      if (user) {
        try {
          await addDoc(collection(db, 'users', user.uid, 'chat_messages'), {
            messageId: assistantMsg.id,
            userId: user.uid,
            role: 'assistant',
            content: assistantMsg.content,
            modelUsed: response.modelUsed,
            groundingMetadata: response.groundingMetadata || null,
            createdAt: new Date().toISOString(),
          });
        } catch (e) {
          console.warn('Error persisting assistant message to Firestore:', e);
        }
      }
    } catch (err) {
      console.warn('Chat request handled fallback:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Live Microphone Dictation (gemini-3.5-transcribe)
  const toggleDictation = () => {
    if (isDictating) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      setIsDictating(false);
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser. Please use keyboard input.');
      return;
    }

    try {
      const recognizer = new SpeechRecognition();
      recognizer.continuous = false;
      recognizer.interimResults = true;
      recognizer.lang = 'en-US';

      recognizer.onstart = () => setIsDictating(true);
      recognizer.onresult = (e) => {
        let text = '';
        for (let i = 0; i < e.results.length; i++) {
          text += e.results[i][0].transcript;
        }
        setInput(text);
      };
      recognizer.onerror = () => setIsDictating(false);
      recognizer.onend = () => setIsDictating(false);

      recognizer.start();
      recognitionRef.current = recognizer;
    } catch (err) {
      console.warn('Dictation notice:', err);
      setIsDictating(false);
    }
  };

  // Live Voice Mode (gemini-3.8-live) Conversation Turn
  const startLiveListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser. Please type your message.');
      return;
    }

    try {
      const recognizer = new SpeechRecognition();
      recognizer.continuous = false;
      recognizer.interimResults = true;
      recognizer.lang = 'en-US';

      recognizer.onstart = () => {
        setIsLiveListening(true);
        setLiveTranscript('');
      };

      recognizer.onresult = (e) => {
        let text = '';
        for (let i = 0; i < e.results.length; i++) {
          text += e.results[i][0].transcript;
        }
        setLiveTranscript(text);
      };

      recognizer.onend = async () => {
        setIsLiveListening(false);
        if (liveTranscript.trim()) {
          await handleLiveTurn(liveTranscript.trim());
        }
      };

      recognizer.onerror = (e) => {
        console.warn('Live recognition notice:', e.error);
        setIsLiveListening(false);
      };

      recognizer.start();
      recognitionRef.current = recognizer;
    } catch (e) {
      setIsLiveListening(false);
    }
  };

  const handleLiveTurn = async (spokenText) => {
    if (!spokenText.trim()) return;
    setIsLiveThinking(true);

    try {
      const res = await sendLiveVoiceMessage(
        spokenText,
        messages.slice(-4).map((m) => ({ role: m.role, content: m.content }))
      );

      setLiveCoachResponse(res.coach_reply || '');

      // Add to chat thread
      const userMsg = {
        id: 'live-user-' + Date.now(),
        role: 'user',
        content: `🎙️ ${spokenText}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      const coachMsg = {
        id: 'live-coach-' + (Date.now() + 1),
        role: 'assistant',
        content: res.coach_reply,
        modelUsed: 'gemini-3.8-live',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, userMsg, coachMsg]);

      // Play synthesized live audio response if available
      if (res.audio_base64) {
        setIsLiveSpeaking(true);
        const audio = new Audio(`data:audio/wav;base64,${res.audio_base64}`);
        liveAudioPlayerRef.current = audio;
        audio.onended = () => setIsLiveSpeaking(false);
        audio.onerror = () => setIsLiveSpeaking(false);
        audio.play().catch(() => setIsLiveSpeaking(false));
      } else {
        // Browser speech synthesis fallback
        if ('speechSynthesis' in window) {
          setIsLiveSpeaking(true);
          const utter = new SpeechSynthesisUtterance(res.coach_reply);
          utter.rate = 1.0;
          utter.pitch = 1.0;
          utter.onend = () => setIsLiveSpeaking(false);
          utter.onerror = () => setIsLiveSpeaking(false);
          window.speechSynthesis.speak(utter);
        }
      }
    } catch (liveErr) {
      console.warn('Live voice session notice:', liveErr);
    } finally {
      setIsLiveThinking(false);
    }
  };

  const quickPrompts = [
    {
      title: 'Eliminate Fillers',
      prompt: 'Give me a 3-step physical vocal drill to completely stop saying "um", "like", and "basically".',
    },
    {
      title: 'Pacing (140 WPM)',
      prompt: 'How do I train my speaking speed to stay within the optimal 130–155 WPM executive range?',
    },
    {
      title: 'The Cork Drill',
      prompt: 'Explain the Classic Cork Drill for hyper-crisp consonant enunciation and projection.',
    },
    {
      title: '2026 Leadership Benchmarks',
      prompt: 'What are current 2026 executive communication benchmarks for keynote presentations and VC pitches?',
      search: true,
    },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Live Voice Conversation Modal (gemini-3.8-live) */}
      {isLiveVoiceOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex flex-col items-center justify-between p-6 sm:p-12 animate-in fade-in zoom-in-95 duration-200">
          <div className="w-full max-w-2xl flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center space-x-2.5">
              <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
              <span className="font-display font-bold text-white text-base tracking-wide">
                Live Voice Conversation <span className="text-brand-400 font-mono text-xs">(gemini-3.8-live)</span>
              </span>
            </div>
            <button
              onClick={() => {
                if (liveAudioPlayerRef.current) liveAudioPlayerRef.current.pause();
                if ('speechSynthesis' in window) window.speechSynthesis.cancel();
                setIsLiveVoiceOpen(false);
              }}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Central Pulsing Vocal Orb */}
          <div className="flex flex-col items-center justify-center space-y-8 my-auto">
            <div className="relative flex items-center justify-center">
              {/* Outer Animated Rings */}
              <div
                className={`absolute w-56 h-56 rounded-full border border-teal-500/20 transition-all duration-700 ${
                  isLiveListening
                    ? 'scale-125 animate-ping border-brand-400/40'
                    : isLiveSpeaking
                    ? 'scale-110 animate-pulse border-cyan-400/40'
                    : ''
                }`}
              />
              <div
                className={`absolute w-44 h-44 rounded-full border border-teal-500/30 transition-all duration-500 ${
                  isLiveListening ? 'scale-110' : ''
                }`}
              />

              {/* Central Glowing Orb */}
              <button
                onClick={startLiveListening}
                disabled={isLiveThinking || isLiveSpeaking}
                className={`relative w-32 h-32 rounded-full flex flex-col items-center justify-center text-slate-950 font-bold shadow-2xl transition-all duration-300 ${
                  isLiveListening
                    ? 'bg-rose-500 scale-105 ring-8 ring-rose-500/30'
                    : isLiveThinking
                    ? 'bg-amber-400 animate-spin'
                    : isLiveSpeaking
                    ? 'bg-gradient-to-tr from-cyan-400 to-teal-300 animate-pulse ring-8 ring-cyan-500/30'
                    : 'bg-gradient-to-tr from-brand-500 via-teal-400 to-cyan-400 hover:scale-105 hover:brightness-110 glow-teal'
                }`}
              >
                {isLiveListening ? (
                  <>
                    <Mic className="w-8 h-8 text-white animate-bounce" />
                    <span className="text-[10px] text-white uppercase tracking-wider mt-1">Listening</span>
                  </>
                ) : isLiveThinking ? (
                  <>
                    <Sparkles className="w-8 h-8 text-slate-950 animate-spin" />
                    <span className="text-[10px] text-slate-950 font-mono mt-1">Thinking</span>
                  </>
                ) : isLiveSpeaking ? (
                  <>
                    <Volume2 className="w-8 h-8 text-slate-950 animate-pulse" />
                    <span className="text-[10px] text-slate-950 uppercase tracking-wider mt-1">Speaking</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-8 h-8 text-slate-950" />
                    <span className="text-[11px] text-slate-950 font-black uppercase tracking-wider mt-1">Tap & Speak</span>
                  </>
                )}
              </button>
            </div>

            {/* Real-Time Live Transcript & Coach Feedback */}
            <div className="max-w-xl text-center space-y-3 px-4 min-h-[100px]">
              {liveTranscript && (
                <p className="text-xs text-slate-400 italic">
                  You: "{liveTranscript}"
                </p>
              )}
              {liveCoachResponse && (
                <p className="text-sm font-medium text-teal-200 leading-relaxed bg-slate-900/80 p-4 rounded-2xl border border-teal-500/30">
                  {liveCoachResponse}
                </p>
              )}
              {!liveTranscript && !liveCoachResponse && (
                <p className="text-xs text-slate-500">
                  Tap the glowing microphone orb to practice vocal pacing, answers, or pitch delivery in real-time with gemini-3.8-live.
                </p>
              )}
            </div>
          </div>

          <div className="text-[11px] text-slate-500 text-center font-mono">
            Powered by gemini-3.8-live · Low Latency Voice API · Continuous Turn-Taking
          </div>
        </div>
      )}

      {/* Header & Feature Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs uppercase font-semibold tracking-wider text-brand-400">
              Interactive Speech Mentor
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-brand-500/10 text-brand-300 border border-brand-500/20 font-mono">
              gemini-3.8-live & gemini-3.5-flash
            </span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-white mt-1">
            VocalLens AI Coach
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time vocal conversation, speech pathology diagnostics, and Google Search grounded benchmarks.
          </p>
        </div>

        {/* Live Voice Mode Button */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => {
              setIsLiveVoiceOpen(true);
              startLiveListening();
            }}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-brand-500 via-teal-400 to-cyan-500 text-slate-950 font-bold text-xs shadow-lg glow-teal hover:brightness-110 flex items-center space-x-2 transition-all"
          >
            <Radio className="w-4 h-4 text-slate-950 animate-pulse" />
            <span>START LIVE VOICE CONVERSATION</span>
          </button>
        </div>
      </div>

      {/* Model & Search Grounding Toolbar */}
      <div className="p-3.5 rounded-2xl glass-panel flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Model Architecture Selector */}
        <div className="flex items-center space-x-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          <button
            onClick={() => setModelType('general')}
            className={`py-1 px-3 rounded-lg font-medium transition-all ${
              modelType === 'general'
                ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            gemini-3.5-flash
          </button>
          <button
            onClick={() => setModelType('complex')}
            className={`py-1 px-3 rounded-lg font-medium transition-all ${
              modelType === 'complex'
                ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            gemini-3.1-pro-preview
          </button>
        </div>

        {/* Google Search Grounding Toggle */}
        <button
          onClick={() => setUseSearch(!useSearch)}
          className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-xl border font-semibold text-xs transition-all ${
            useSearch
              ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <Search className={`w-3.5 h-3.5 ${useSearch ? 'text-cyan-400' : 'text-slate-500'}`} />
          <span>Google Search Grounding: {useSearch ? 'ON' : 'OFF'}</span>
        </button>
      </div>

      {/* Chat Thread Card */}
      <div className="rounded-2xl glass-panel flex flex-col h-[520px] overflow-hidden">
        {/* Messages Container */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          {messages.map((m) => {
            const isUser = m.role === 'user';
            return (
              <div
                key={m.id}
                className={`flex items-start space-x-3 ${
                  isUser ? 'flex-row-reverse space-x-reverse' : 'flex-row'
                }`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                    isUser
                      ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                      : 'bg-brand-500/20 text-brand-300 border border-brand-500/30'
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Bubble */}
                <div
                  className={`max-w-[85%] sm:max-w-xl p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-teal-950/40 border border-teal-500/30 text-teal-100 rounded-tr-none'
                      : 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-tl-none'
                  }`}
                >
                  {/* Header info */}
                  <div className="flex items-center justify-between text-[10px] text-slate-400 border-b border-slate-800/60 pb-1 mb-1.5">
                    <span className="font-semibold text-slate-300">
                      {isUser ? 'You' : 'VocalLens Coach'}
                    </span>
                    <div className="flex items-center space-x-2 font-mono">
                      {!isUser && m.modelUsed && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-brand-300">
                          {m.modelUsed}
                        </span>
                      )}
                      <span>{m.timestamp}</span>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="whitespace-pre-wrap">{m.content}</div>

                  {/* Google Search Grounding Sources / Citations */}
                  {m.groundingMetadata?.groundingChunks && m.groundingMetadata.groundingChunks.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-slate-800 text-[11px] space-y-1.5 bg-slate-950/40 p-2.5 rounded-lg">
                      <div className="flex items-center space-x-1.5 text-cyan-400 font-semibold">
                        <Search className="w-3 h-3" />
                        <span>Google Search Grounding Sources</span>
                      </div>
                      <div className="space-y-1">
                        {m.groundingMetadata.groundingChunks.map((chunk, cIdx) => {
                          const web = chunk.web;
                          if (!web) return null;
                          return (
                            <a
                              key={cIdx}
                              href={web.uri}
                              target="_blank"
                              rel="noreferrer"
                              className="flex items-center space-x-1 text-slate-400 hover:text-brand-300 transition-colors truncate block"
                            >
                              <ExternalLink className="w-2.5 h-2.5 flex-shrink-0" />
                              <span className="truncate">{web.title || web.uri}</span>
                            </a>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {/* Typing Indicator */}
          {isLoading && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 rounded-xl bg-brand-500/20 text-brand-300 border border-brand-500/30 flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-400 flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-brand-400 animate-pulse" />
                <div className="w-2 h-2 rounded-full bg-brand-400 animate-pulse delay-75" />
                <div className="w-2 h-2 rounded-full bg-brand-400 animate-pulse delay-150" />
                <span className="font-mono text-[11px]">
                  {useSearch ? 'Searching Google & synthesizing...' : 'Synthesizing coaching drills...'}
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-950/50 flex items-center space-x-2 overflow-x-auto no-scrollbar">
          <span className="text-[10px] uppercase font-bold text-slate-500 flex-shrink-0">
            Quick Drills:
          </span>
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => {
                if (qp.search) setUseSearch(true);
                handleSend(qp.prompt);
              }}
              className="flex-shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-brand-300 border border-slate-800 transition-colors"
            >
              {qp.title}
            </button>
          ))}
        </div>

        {/* Input Bar with Voice Dictation (gemini-3.5-transcribe) */}
        <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-950/80">
          <div className="flex items-center space-x-2">
            <button
              onClick={toggleDictation}
              className={`p-3 rounded-xl border transition-all ${
                isDictating
                  ? 'bg-rose-500 text-white border-rose-400 animate-pulse'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-brand-300 hover:border-slate-700'
              }`}
              title="Dictate with microphone (gemini-3.5-transcribe)"
            >
              <Mic className="w-4 h-4" />
            </button>

            <textarea
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={
                isDictating
                  ? 'Listening to your speech...'
                  : useSearch
                  ? 'Ask any communication question with live Google Search grounding...'
                  : 'Ask your speech coach about pacing, fillers, pitch modulation, or interview drills...'
              }
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-400 resize-none max-h-32"
            />

            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || isLoading}
              className="p-3 rounded-xl bg-brand-500 hover:bg-brand-400 disabled:bg-slate-800 text-slate-950 disabled:text-slate-600 font-bold transition-all glow-teal disabled:glow-none"
              title="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
